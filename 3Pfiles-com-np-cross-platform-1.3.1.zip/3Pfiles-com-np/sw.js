const CACHE_NAME = '3pfiles-shell-v1';
const APP_SHELL = ['/', '/index.html', '/account.html', '/manifest.webmanifest', '/src/css/style.css', '/src/css/account.css', '/src/js/app.js', '/src/js/account.js', '/src/js/pwa.js', '/src/assets/icons/app.png'];
self.addEventListener('install', event => { event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL))); self.skipWaiting(); });
self.addEventListener('activate', event => { event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/API/') || url.pathname.startsWith('/oauth/') || url.pathname.startsWith('/s/')) return;
  event.respondWith(fetch(request).then(response => { if (response.ok && (request.mode === 'navigate' || APP_SHELL.includes(url.pathname))) { const copy = response.clone(); caches.open(CACHE_NAME).then(cache => cache.put(request, copy)); } return response; }).catch(async () => (await caches.match(request)) || (request.mode === 'navigate' ? caches.match('/') : Response.error())));
});
