'use strict';

const http = require('http');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const { pipeline } = require('stream/promises');
const { Transform } = require('stream');
const crypto = require('crypto');

function loadEnvironmentFile() {
  try {
    const content = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
    for (const line of content.split(/\r?\n/)) {
      const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if (!match || match[1].startsWith('#') || process.env[match[1]] !== undefined) continue;
      let value = match[2];
      if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1,-1);
      process.env[match[1]] = value;
    }
  } catch (err) { if (err.code !== 'ENOENT') throw err; }
}
loadEnvironmentFile();

const portArgIndex = process.argv.indexOf('--port');
const portArg = process.argv.find(arg => arg.startsWith('--port='));
const configuredPort = process.env.PORT || process.env.P3_PORT || (portArgIndex >= 0 ? process.argv[portArgIndex + 1] : '') || (portArg ? portArg.slice('--port='.length) : '') || '3000';
const PORT = Number(configuredPort);
if (!Number.isInteger(PORT) || PORT < 1 || PORT > 65535) throw new Error('Invalid port: ' + configuredPort + '. Choose a number from 1 to 65535.');
const MAX_UPLOAD_BYTES = 1000000000;
const MAX_ACTIVE_JOBS = 1;
let activeJobs = 0;
const ROOT = __dirname;
const ROOT_PREFIX = path.resolve(ROOT) + path.sep;
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon',
  '.exe': 'application/octet-stream', '.dmg': 'application/octet-stream',
  '.AppImage': 'application/octet-stream', '.deb': 'application/vnd.debian.binary-package',
  '.zip': 'application/zip', '.3p': 'application/octet-stream'
};


const PRIVATE_DIR = process.env.P3_DATA_DIR ? path.resolve(process.env.P3_DATA_DIR) : path.join(ROOT, 'user', '.private');
const SHARES_DIR = path.join(PRIVATE_DIR, 'shares');
const ACCOUNT_FILES_DIR = path.join(PRIVATE_DIR, 'account-files');
const ACCOUNTS_FILE = path.join(PRIVATE_DIR, 'accounts.json');
const SHARES_FILE = path.join(SHARES_DIR, 'index.json');
const SHARE_TTL_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_SHARE_BYTES = 1000000000;
const DEFAULT_ADMIN_PASSWORD = process.env.DEFAULT_ADMIN_PASSWORD || 'thisisadmin';
const sessions = new Map();
let accounts = {};
let shares = {};
function json(res, status, value) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(value)); }
function saveJson(file, value) { const tmp = file + '.tmp'; return fsp.writeFile(tmp, JSON.stringify(value, null, 2), { mode: 0o600 }).then(() => fsp.rename(tmp, file)); }
function derivePassword(password, salt) { return new Promise((resolve, reject) => crypto.scrypt(password, salt, 64, (err, key) => err ? reject(err) : resolve(key.toString('hex')))); }
async function initAuth() {
  await fsp.mkdir(SHARES_DIR, { recursive: true });
  await fsp.mkdir(ACCOUNT_FILES_DIR, { recursive: true });
  try { accounts = JSON.parse(await fsp.readFile(ACCOUNTS_FILE, 'utf8')); } catch (err) { if (err.code !== 'ENOENT') throw err; }
  try { shares = JSON.parse(await fsp.readFile(SHARES_FILE, 'utf8')); } catch (err) { if (err.code !== 'ENOENT') throw err; }
  let changed = false;
  for (const token of Object.keys(shares)) if (shares[token].expiresAt <= Date.now() && !shares[token].expired) { await fsp.rm(path.join(SHARES_DIR, token + '.3p'), { force: true }); shares[token].expired = true; changed = true; }
  if (changed) await saveJson(SHARES_FILE, shares);
  if (!accounts.admin) { const salt = crypto.randomBytes(16).toString('hex'); accounts.admin = { username: 'admin', email: 'admin@3pfiles.local', salt, passwordHash: await derivePassword(DEFAULT_ADMIN_PASSWORD, salt), notifications: [{ text: 'Welcome to the default admin account.', createdAt: new Date().toISOString(), read: false }] }; await saveJson(ACCOUNTS_FILE, accounts); }
}
const authReady = initAuth();
const oauthStates = new Map();
const FACEBOOK_VERSION = process.env.FACEBOOK_GRAPH_VERSION || 'v27.0';
function providerConfig(name) {
  const base = (process.env.PUBLIC_BASE_URL || ('http://localhost:' + PORT)).replace(/\/$/, '');
  const configs = {
    google: { clientId: process.env.GOOGLE_CLIENT_ID, clientSecret: process.env.GOOGLE_CLIENT_SECRET, auth: 'https://accounts.google.com/o/oauth2/v2/auth', token: 'https://oauth2.googleapis.com/token', profile: 'https://openidconnect.googleapis.com/v1/userinfo', scope: 'openid email profile' },
    facebook: { clientId: process.env.FACEBOOK_CLIENT_ID, clientSecret: process.env.FACEBOOK_CLIENT_SECRET, auth: 'https://www.facebook.com/' + FACEBOOK_VERSION + '/dialog/oauth', token: 'https://graph.facebook.com/' + FACEBOOK_VERSION + '/oauth/access_token', profile: 'https://graph.facebook.com/' + FACEBOOK_VERSION + '/me', scope: 'email,public_profile' },
    discord: { clientId: process.env.DISCORD_CLIENT_ID, clientSecret: process.env.DISCORD_CLIENT_SECRET, auth: 'https://discord.com/oauth2/authorize', token: 'https://discord.com/api/oauth2/token', profile: 'https://discord.com/api/users/@me', scope: 'identify email' },
    apple: { clientId: process.env.APPLE_CLIENT_ID, teamId: process.env.APPLE_TEAM_ID, keyId: process.env.APPLE_KEY_ID, privateKey: process.env.APPLE_PRIVATE_KEY, auth: 'https://appleid.apple.com/auth/authorize', token: 'https://appleid.apple.com/auth/token', scope: 'name email' }
  };
  const c = configs[name]; if (!c) return null;
  c.redirectUri = base + '/oauth/' + name + '/callback';
  c.enabled = name === 'apple' ? !!(c.clientId && c.teamId && c.keyId && c.privateKey) : !!(c.clientId && c.clientSecret);
  return c;
}
async function fetchJson(url, options) {
  const response = await fetch(url, options), data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error_description || data.error || 'The identity provider rejected the sign-in.');
  return data;
}
function appleClientSecret(config) {
  const b64 = value => Buffer.from(JSON.stringify(value)).toString('base64url');
  const head = b64({ alg: 'ES256', kid: config.keyId, typ: 'JWT' });
  const now = Math.floor(Date.now() / 1000), body = b64({ iss: config.teamId, iat: now, exp: now + 86400, aud: 'https://appleid.apple.com', sub: config.clientId });
  const key = config.privateKey.replace(/\\n/g, '\n');
  const signature = crypto.sign('sha256', Buffer.from(head + '.' + body), { key, dsaEncoding: 'ieee-p1363' }).toString('base64url');
  return head + '.' + body + '.' + signature;
}
async function verifyAppleToken(jwt, config, nonce) {
  const parts = jwt.split('.'); if (parts.length !== 3) throw new Error('Apple returned an invalid identity token.');
  const decode = value => JSON.parse(Buffer.from(value, 'base64url').toString('utf8'));
  const head = decode(parts[0]), claims = decode(parts[1]);
  if (head.alg !== 'RS256' || !head.kid) throw new Error('Apple returned an unsupported identity token.');
  const keys = await fetchJson('https://appleid.apple.com/auth/keys');
  const jwk = (keys.keys || []).find(k => k.kid === head.kid && k.kty === 'RSA');
  if (!jwk) throw new Error('Could not verify Apple identity token.');
  const publicKey = crypto.createPublicKey({ key: jwk, format: 'jwk' });
  if (!crypto.verify('RSA-SHA256', Buffer.from(parts[0] + '.' + parts[1]), publicKey, Buffer.from(parts[2], 'base64url'))) throw new Error('Apple identity token signature is invalid.');
  if (claims.iss !== 'https://appleid.apple.com' || claims.aud !== config.clientId || claims.exp <= Date.now() / 1000 || claims.nonce !== nonce) throw new Error('Apple identity token claims did not validate.');
  return claims;
}
function parseForm(text) { return Object.fromEntries(new URLSearchParams(text)); }
async function readText(req, max) { let n=0, chunks=[]; for await(const c of req){n+=c.length;if(n>max)throw Error('OAuth response is too large.');chunks.push(c);} return Buffer.concat(chunks).toString('utf8'); }
function oauthStateCookie(req,name,state,clear=false) { const secure=req.socket.encrypted||String(req.headers['x-forwarded-proto']||'').split(',')[0].trim()==='https'||name==='apple'; const same=name==='apple'?'None':'Lax'; return '3p_oauth_'+name+'='+(clear?'':state)+'; Path=/oauth/'+name+'/callback; HttpOnly; SameSite='+same+'; Max-Age='+(clear?'0':'600')+(secure?'; Secure':''); }
function readCookie(req,name) { const item=String(req.headers.cookie||'').split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'=')); return item?item.slice(name.length+1):''; }
async function oauthBegin(req, res, name) {
  const c=providerConfig(name); if(!c||!c.enabled){res.writeHead(302,{Location:'/?authError=provider_not_configured'});return res.end();}
  for(const [key,value] of oauthStates)if(value.expiresAt<Date.now())oauthStates.delete(key);
  const state=crypto.randomBytes(32).toString('hex'),nonce=crypto.randomBytes(32).toString('hex');oauthStates.set(state,{name,nonce,expiresAt:Date.now()+600000});
  res.setHeader('Set-Cookie',oauthStateCookie(req,name,state));
  const u=new URL(c.auth);u.searchParams.set('client_id',c.clientId);u.searchParams.set('redirect_uri',c.redirectUri);u.searchParams.set('response_type',name==='apple'?'code id_token':'code');u.searchParams.set('scope',c.scope);u.searchParams.set('state',state);
  if(name==='facebook')u.searchParams.set('auth_type','rerequest');
  if(name==='discord')u.searchParams.set('prompt','consent');
  if(name==='apple'){u.searchParams.set('response_mode','form_post');u.searchParams.set('nonce',nonce);}
  res.writeHead(302,{Location:u.toString(), 'Cache-Control':'no-store'});res.end();
}
async function oauthIdentity(name, config, code, nonce, providerUser) {
  const form = new URLSearchParams({ client_id: config.clientId, client_secret: name==='apple'?appleClientSecret(config):config.clientSecret, code, grant_type:'authorization_code', redirect_uri:config.redirectUri });
  let token;
  if(name==='facebook') { const u=new URL(config.token);for(const [k,v] of form)u.searchParams.set(k,v);token=await fetchJson(u); }
  else token=await fetchJson(config.token,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form});
  let profile;
  if(name==='google') profile=await fetchJson(config.profile,{headers:{Authorization:'Bearer '+token.access_token}});
  else if(name==='facebook') { const u=new URL(config.profile);u.searchParams.set('fields','id,name,email');u.searchParams.set('access_token',token.access_token);profile=await fetchJson(u); }
  else if(name==='discord') profile=await fetchJson(config.profile,{headers:{Authorization:'Bearer '+token.access_token}});
  else { const claims=await verifyAppleToken(token.id_token,config,nonce);profile={id:claims.sub,email:claims.email,name:providerUser&&providerUser.name?String(providerUser.name.firstName||'')+' '+String(providerUser.name.lastName||''):'Apple user',email_verified:claims.email_verified}; }
  const subject=String(name==='google'?profile.sub:profile.id||''); const email=String(profile.email||'').trim().toLowerCase();
  if(!subject||!email||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw new Error('The provider did not return a usable email address. Allow email access and try again.');
  if(name==='google'&&String(profile.email_verified)==='false')throw new Error('Verify your Google email before signing in.');
  return {subject,email};
}
async function finishOAuth(name, req, res) {
  try {
    const config=providerConfig(name);if(!config||!config.enabled)throw new Error('This sign-in provider is not configured.');
    let params;
    if(req.method==='POST')params=parseForm(await readText(req,32768));else params=Object.fromEntries(new URL(req.url,'http://localhost').searchParams);
    if(params.error)throw new Error('Sign-in was cancelled or declined.');
    const state=String(params.state||''),pending=oauthStates.get(state);oauthStates.delete(state);
    if(!pending||pending.name!==name||pending.expiresAt<Date.now()||readCookie(req,'3p_oauth_'+name)!==state)throw new Error('Sign-in expired. Start again.');
    if(!params.code)throw new Error('The provider did not return an authorization code.');
    let appleUser=null;if(name==='apple'&&params.user){try{appleUser=JSON.parse(params.user);}catch(_){}}
    const identity=await oauthIdentity(name,config,params.code,pending.nonce,appleUser);
    let key=Object.keys(accounts).find(k=>accounts[k].oauth&&accounts[k].oauth[name]===identity.subject);
    if(!key){let stem=(name+'_'+identity.subject.replace(/[^a-zA-Z0-9_]/g,'')).slice(0,27),username=stem;while(accounts[username.toLowerCase()])username=(stem.slice(0,20)+'_'+crypto.randomBytes(3).toString('hex'));key=username.toLowerCase();accounts[key]={username,email:identity.email,salt:'',passwordHash:'',oauth:{[name]:identity.subject},salt:crypto.randomBytes(16).toString('hex'),passwordHash:crypto.randomBytes(64).toString('hex'),notifications:[]};await addNotification(key,'Your '+name+' account is connected.');await saveJson(ACCOUNTS_FILE,accounts);}
    setSession(res,key,req);res.setHeader('Set-Cookie',[res.getHeader('Set-Cookie'),oauthStateCookie(req,name,'',true)]);res.writeHead(302,{Location:'/?auth=success','Cache-Control':'no-store'});res.end();
  } catch(err) { res.setHeader('Set-Cookie',oauthStateCookie(req,name,'',true));res.writeHead(302,{Location:'/?authError='+encodeURIComponent(err.message||'oauth_failed'),'Cache-Control':'no-store'});res.end(); }
}

function sessionUser(req) { const c = String(req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith('3p_session=')); if (!c) return null; const token = c.slice(11), v = sessions.get(token); if (!v || v.expiresAt <= Date.now()) { sessions.delete(token); return null; } return accounts[v.username] || null; }
function setSession(res, username, req) { const t = crypto.randomBytes(32).toString('hex'); sessions.set(t, { username, expiresAt: Date.now() + 604800000 }); const secure = req.socket.encrypted || String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https'; res.setHeader('Set-Cookie', '3p_session=' + t + '; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800' + (secure ? '; Secure' : '')); }
function clearSession(res, req) { const c = String(req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith('3p_session=')); if (c) sessions.delete(c.slice(11)); const secure = req.socket.encrypted || String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https'; res.setHeader('Set-Cookie', '3p_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0' + (secure ? '; Secure' : '')); }
async function readJson(req, max) { let n = 0, chunks = []; for await (const c of req) { n += c.length; if (n > max) throw Object.assign(Error('Request body is too large.'), { statusCode: 413 }); chunks.push(c); } try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (_) { throw Object.assign(Error('Invalid JSON request.'), { statusCode: 400 }); } }
function publicUser(u) { return { username: u.username, email: u.email }; }
async function addNotification(key, text) { const u = accounts[key]; if (!u) return; u.notifications = u.notifications || []; u.notifications.unshift({ text, createdAt: new Date().toISOString(), read: false }); u.notifications = u.notifications.slice(0, 50); await saveJson(ACCOUNTS_FILE, accounts); }
async function authApi(req, res, pathname) {
 await authReady;
 if (pathname === '/API/v1/auth/signup' && req.method === 'POST') { const d = await readJson(req, 16384), username = String(d.username || '').trim(), key = username.toLowerCase(), email = String(d.email || '').trim().toLowerCase(), password = String(d.password || ''); if (!/^[a-zA-Z0-9_]{3,32}$/.test(username)) return json(res,400,{error:'Username must be 3–32 letters, numbers, or underscores.'}); if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json(res,400,{error:'Enter a valid email address.'}); if (password.length < 10 || password.length > 256) return json(res,400,{error:'Password must be 10–256 characters.'}); if (accounts[key]) return json(res,409,{error:'That username is already taken.'}); const salt=crypto.randomBytes(16).toString('hex'); accounts[key]={username,email,salt,passwordHash:await derivePassword(password,salt),notifications:[]}; await addNotification(key,'Welcome to 3Pfiles. Your account is ready.'); setSession(res,key,req); return json(res,201,{user:publicUser(accounts[key])}); }
 if (pathname === '/API/v1/auth/login' && req.method === 'POST') { const d=await readJson(req,16384),key=String(d.username||'').trim().toLowerCase(),u=accounts[key]; if (!u) return json(res,401,{error:'Username or password is incorrect.'}); const got=Buffer.from(await derivePassword(String(d.password||''),u.salt),'hex'),want=Buffer.from(u.passwordHash,'hex'); if (got.length!==want.length || !crypto.timingSafeEqual(got,want)) return json(res,401,{error:'Username or password is incorrect.'}); setSession(res,key,req); return json(res,200,{user:publicUser(u)}); }
 if (pathname === '/API/v1/auth/logout' && req.method === 'POST') { clearSession(res,req); return json(res,200,{ok:true}); }
 if (pathname === '/API/v1/auth/me' && req.method === 'GET') { const u=sessionUser(req); return u?json(res,200,{user:publicUser(u)}):json(res,401,{error:'Sign in required.'}); }
 if (pathname === '/API/v1/notifications' && req.method === 'GET') { const u=sessionUser(req); return u?json(res,200,{notifications:u.notifications||[]}):json(res,401,{error:'Sign in required.'}); }
 if (pathname === '/API/v1/notifications/read' && req.method === 'POST') { const u=sessionUser(req); if(!u)return json(res,401,{error:'Sign in required.'}); (u.notifications||[]).forEach(x=>x.read=true); await saveJson(ACCOUNTS_FILE,accounts); return json(res,200,{ok:true}); }
 if (pathname === '/API/v1/notifications/download' && req.method === 'POST') { const u=sessionUser(req); if(!u)return json(res,401,{error:'Sign in required.'}); const d=await readJson(req,4096), name=outputName(d.fileName); if(!name)return json(res,400,{error:'Enter a valid downloaded file name.'}); const stored=(u.files||[]).find(item=>item.id===d.libraryId); if(stored)stored.downloadedAt=new Date().toISOString(); else { const installers={'3Pfile-Linux-x86_64.deb':'/files/3Pfile-Linux-x86_64.deb','3Pfile-Setup-Win64.exe':'/files/3Pfile-Setup-Win64.exe','3Pfile-Installer-Universal.dmg':'/files/3Pfile-Installer-Universal.dmg'}, publicPath=installers[name]; if(publicPath){let size=0;try{size=(await fsp.stat(path.join(ROOT,publicPath.slice(1)))).size;}catch(_){} u.files=Array.isArray(u.files)?u.files:[];u.files.unshift({id:crypto.randomBytes(16).toString('hex'),fileName:name,operation:'installer',size,createdAt:new Date().toISOString(),downloadedAt:new Date().toISOString(),downloadPath:publicPath,deletedAt:null});} } await addNotification(u.username,'Downloaded '+name+'.'); return json(res,201,{ok:true}); }
 return false;
}
async function storeAccountFile(user, source, fileName, operation, size) {
  const id=crypto.randomBytes(16).toString('hex'), key=user.username.toLowerCase(), dir=path.join(ACCOUNT_FILES_DIR,key);
  await fsp.mkdir(dir,{recursive:true}); await fsp.copyFile(source,path.join(dir,id+'.bin'));
  const item={id,fileName:outputName(fileName),operation,size,createdAt:new Date().toISOString(),deletedAt:null};
  user.files=Array.isArray(user.files)?user.files:[]; user.files.unshift(item); await saveJson(ACCOUNTS_FILE,accounts); return item;
}
function accountFileResponse(item, direction, otherEmail, deleted, extra={}) {
  return {id:(item.id?'file-'+item.id:'share-'+item.token),fileName:item.fileName,size:Number(item.size)||0,createdAt:item.createdAt||new Date(item.expiresAt||Date.now()).toISOString(),operation:item.operation||'shared',direction,otherEmail:otherEmail||'',deleted:!!deleted,expired:!!item.expired,folderId:item.folderId||'',...extra};
}
async function accountFilesApi(req,res,url) {
  await authReady;
  const user=sessionUser(req);
  if(!user)return json(res,401,{error:'Sign in required.'});
  const key=user.username.toLowerCase();
  if(url.pathname==='/API/v1/account/folders'&&req.method==='GET')return json(res,200,{folders:user.folders||[]});
  if(url.pathname==='/API/v1/account/folders'&&req.method==='POST'){
    const d=await readJson(req,4096),name=String(d.name||'').trim();
    if(name.length<1||name.length>40)return json(res,400,{error:'Folder names must be 1–40 characters.'});
    user.folders=Array.isArray(user.folders)?user.folders:[];
    if(user.folders.some(folder=>folder.name.toLowerCase()===name.toLowerCase()))return json(res,409,{error:'A folder with that name already exists.'});
    const folder={id:crypto.randomBytes(8).toString('hex'),name};user.folders.push(folder);await saveJson(ACCOUNTS_FILE,accounts);return json(res,201,{folder});
  }
  if(url.pathname==='/API/v1/account/files'&&req.method==='GET'){
    user.files=Array.isArray(user.files)?user.files:[];let migrated=false;const knownDownloads=new Set(user.files.map(item=>String(item.fileName||'').toLowerCase()));
    const installers={'3Pfile-Linux-x86_64.deb':'/files/3Pfile-Linux-x86_64.deb','3Pfile-Setup-Win64.exe':'/files/3Pfile-Setup-Win64.exe','3Pfile-Installer-Universal.dmg':'/files/3Pfile-Installer-Universal.dmg'};
    for(const note of user.notifications||[]){const hit=String(note.text||'').match(/^Downloaded (.+)\.$/);if(!hit)continue;const fileName=outputName(hit[1]);if(!fileName||knownDownloads.has(fileName.toLowerCase()))continue;knownDownloads.add(fileName.toLowerCase());user.files.push({id:crypto.randomBytes(16).toString('hex'),fileName,operation:'history',size:0,createdAt:note.createdAt,downloadedAt:note.createdAt,downloadPath:installers[fileName]||null,historyOnly:true,deletedAt:null});migrated=true;}
    if(migrated)await saveJson(ACCOUNTS_FILE,accounts);
    const items=user.files.map(item=>accountFileResponse(item,'download','',!!item.deletedAt,{downloadUrl:item.downloadPath||('/API/v1/account/files/file-'+item.id+'/download'),historyOnly:!!item.historyOnly}));
    for(const [token,share] of Object.entries(shares)){
      const ownerKey=String(share.owner||'').toLowerCase(),incoming=String(share.recipient||'').toLowerCase()===String(user.email||'').toLowerCase(),outgoing=ownerKey===key;if(!incoming&&!outgoing)continue;
      const deleted=!!(share.deletedFor&&share.deletedFor[key]);let size=Number(share.size)||0;if(!size)try{size=(await fsp.stat(path.join(SHARES_DIR,token+'.3p'))).size;}catch(_){}
      items.push(accountFileResponse({...share,token,size},incoming?'received':'sent',incoming?(accounts[ownerKey]&&accounts[ownerKey].email||share.owner):share.recipient,deleted,{folderId:share.folderByUser&&share.folderByUser[key]||'',downloadUrl:(share.expiresAt>Date.now()&&!share.expired)?'/API/v1/account/files/share-'+token+'/download':null}));
    }
    return json(res,200,{items,folders:user.folders||[]});
  }
  const match=url.pathname.match(/^\/API\/v1\/account\/files\/(file|share)-([a-f0-9]{32}|[a-f0-9]{48})\/(download|delete|restore|folder)$/);
  if(!match)return json(res,404,{error:'File record not found.'});
  const [,kind,id,action]=match;
  let item=null,share=null;
  if(kind==='file'){item=(user.files||[]).find(entry=>entry.id===id);if(!item)return json(res,404,{error:'File record not found.'});}
  else {share=shares[id];if(!share)return json(res,404,{error:'Share record not found.'});const owner=String(share.owner||'').toLowerCase()===key,incoming=String(share.recipient||'').toLowerCase()===String(user.email||'').toLowerCase();if(!owner&&!incoming)return json(res,403,{error:'This share is not associated with your account.'});}
  if(action==='folder'){
    if(req.method!=='POST')return json(res,405,{error:'Use POST to move this file.'});const d=await readJson(req,4096),folderId=String(d.folderId||'');if(folderId&&!(user.folders||[]).some(folder=>folder.id===folderId))return json(res,400,{error:'Choose one of your folders.'});
    if(item){item.folderId=folderId;await saveJson(ACCOUNTS_FILE,accounts);}else{share.folderByUser=share.folderByUser||{};share.folderByUser[key]=folderId;await saveJson(SHARES_FILE,shares);}return json(res,200,{ok:true});
  }
  if(action==='delete'||action==='restore'){
    if(req.method!=='POST')return json(res,405,{error:'Use POST for this action.'});if(item){item.deletedAt=action==='delete'?new Date().toISOString():null;await saveJson(ACCOUNTS_FILE,accounts);}else{share.deletedFor=share.deletedFor||{};share.deletedFor[key]=action==='delete';await saveJson(SHARES_FILE,shares);}return json(res,200,{ok:true});
  }
  if(req.method!=='GET')return json(res,405,{error:'Use GET to download this file.'});
  if(item){if(item.deletedAt)return json(res,410,{error:'This file is marked as deleted.'});if(item.downloadPath){res.writeHead(302,{Location:item.downloadPath,'Cache-Control':'no-store'});return res.end();}const file=path.join(ACCOUNT_FILES_DIR,key,id+'.bin');try{const st=await fsp.stat(file),safe=outputName(item.fileName);await addNotification(user.username,'Downloaded '+safe+'.');res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':st.size,'Content-Disposition':'attachment; filename='+encodeURIComponent(safe),'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'});return fs.createReadStream(file).pipe(res);}catch(_){return json(res,404,{error:'Stored file is no longer available.'});}}
  if(share.deletedFor&&share.deletedFor[key])return json(res,410,{error:'This file is marked as deleted.'});if(share.expiresAt<=Date.now()||share.expired)return json(res,410,{error:'This share link has expired.'});await addNotification(user.username,'Downloaded shared file '+outputName(share.fileName)+'.');return serveShare(res,id);
}

async function createShare(req,res) {
 await authReady; const u=sessionUser(req); if(!u)return json(res,401,{error:'Sign in to share a compressed file.'}); const to=String(req.headers['x-recipient-email']||'').trim().toLowerCase(); if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(to))return json(res,400,{error:'Enter a valid recipient email address.'}); const name=outputName(req.headers['x-file-name']); if(!name||!name.toLowerCase().endsWith('.3p'))return json(res,400,{error:'The shared file must be a .3p archive.'}); if(Number(req.headers['content-length']||0)>MAX_SHARE_BYTES)return json(res,413,{error:'Shared archives are limited to 1 GB.'}); const token=crypto.randomBytes(24).toString('hex'),file=path.join(SHARES_DIR,token+'.3p'); let count=0; const limiter=new Transform({transform(c,e,cb){count+=c.length;if(count>MAX_SHARE_BYTES)return cb(Object.assign(Error('Shared archives are limited to 1 GB.'),{statusCode:413}));cb(null,c);}});
 try { await pipeline(req,limiter,fs.createWriteStream(file,{flags:'wx',mode:0o600})); if(!count){await fsp.rm(file,{force:true});return json(res,400,{error:'The archive is empty.'});} shares[token]={fileName:name,recipient:to,owner:u.username,size:count,createdAt:new Date().toISOString(),deletedFor:{},expiresAt:Date.now()+SHARE_TTL_MS}; await saveJson(SHARES_FILE,shares); await addNotification(u.username,'Share link created for '+name+' addressed to '+to+'.'); return json(res,201,{token,fileName:name,expiresAt:new Date(shares[token].expiresAt).toISOString()}); } catch(e) { await fsp.rm(file,{force:true}); return json(res,e.statusCode||500,{error:e.statusCode?e.message:'Could not create a share link.'}); }
}
async function extract(req,res) {
  const name=outputName(req.headers['x-file-name']); if(!name||!name.toLowerCase().endsWith('.3p'))return json(res,400,{error:'Choose a .3p archive to uncompress.'});
  if(Number(req.headers['content-length']||0)>MAX_UPLOAD_BYTES)return json(res,413,{error:'Archives are limited to 1 GB.'});
  let jobDir;try {
    jobDir=await fsp.mkdtemp(path.join(os.tmpdir(),'3pfiles-extract-'));const archive=path.join(jobDir,name),restoreDir=path.join(jobDir,'restored');await fsp.mkdir(restoreDir);
    let received=0;const limiter=new Transform({transform(chunk,enc,done){received+=chunk.length;if(received>MAX_UPLOAD_BYTES)return done(Object.assign(Error('Archives are limited to 1 GB.'),{statusCode:413}));done(null,chunk);}});
    await pipeline(req,limiter,fs.createWriteStream(archive,{flags:'wx'}));if(!received)return json(res,400,{error:'The archive is empty.'});
    const executable=cliPath();await fsp.access(executable,fs.constants.X_OK).catch(async err=>{if(process.platform==='win32'&&err.code!=='ENOENT')return;throw err;});
    const inspect=await runCli(executable,['i',archive]);if(inspect.code!==0)return json(res,400,{error:'This is not a valid .3p archive.'});
    const originalMatch=inspect.output.match(/original=(\d+)/);if(!originalMatch)return json(res,400,{error:'Could not read archive metadata.'});
    if(Number(originalMatch[1])>MAX_UPLOAD_BYTES)return json(res,413,{error:'Restored files are limited to 1 GB.'});
    const restored=await runCli(executable,['x',archive,restoreDir,'-q']);if(restored.code!==0)return json(res,400,{error:'The .3p archive is damaged or could not be restored.'});
    const entries=await fsp.readdir(restoreDir);if(entries.length!==1)return json(res,500,{error:'Could not find the restored file.'});
    const file=path.join(restoreDir,entries[0]),stats=await fsp.stat(file);if(!stats.isFile()||stats.size>MAX_UPLOAD_BYTES)return json(res,413,{error:'Restored files are limited to 1 GB.'});
    const user=sessionUser(req),libraryItem=user?await storeAccountFile(user,file,entries[0],'restored',stats.size):null;
     const encoded=encodeURIComponent(entries[0]).replace(/['()*]/g,ch=>'%'+ch.charCodeAt(0).toString(16).toUpperCase());
    res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':stats.size,'Content-Disposition':"attachment; filename*=UTF-8''"+encoded,'X-Output-Name':encoded,...(libraryItem?{'X-Library-Id':libraryItem.id}:{}),'Cache-Control':'no-store'});
    await pipeline(fs.createReadStream(file),res);
  } catch(err) {if(res.headersSent){res.destroy(err);return;}if(err.statusCode)return json(res,err.statusCode,{error:err.message});if(err.code==='ENOENT')return json(res,503,{error:'The native 3P compressor is not installed for this server platform yet.'});console.error('Uncompression service failed:',err);return json(res,500,{error:'Uncompression service failed.'});}
  finally {if(jobDir)await fsp.rm(jobDir,{recursive:true,force:true}).catch(()=>{});}
}
function runCli(executable,args) {
  return new Promise((resolve,reject)=>{const child=spawn(executable,args,{windowsHide:true,stdio:['ignore','pipe','pipe']});let output='';child.stdout.setEncoding('utf8');child.stderr.setEncoding('utf8');child.stdout.on('data',part=>{if(output.length<8192)output+=part;});child.stderr.on('data',part=>{if(output.length<8192)output+=part;});child.once('error',reject);child.once('close',code=>resolve({code,output}));});
}
async function serveShare(res,token) { await authReady; const item=shares[token]; if(!item)return json(res,404,{error:'This share link has expired or does not exist.'}); if(item.expiresAt<=Date.now()){item.expired=true;await fsp.rm(path.join(SHARES_DIR,token+'.3p'),{force:true});await saveJson(SHARES_FILE,shares);return json(res,404,{error:'This share link has expired or does not exist.'});} const file=path.join(SHARES_DIR,token+'.3p'); try{const st=await fsp.stat(file);res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':st.size,'Content-Disposition':'attachment; filename="'+item.fileName.replace(/["\\]/g,'_')+'"','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'});fs.createReadStream(file).pipe(res);}catch(_){return json(res,404,{error:'This share link has expired or does not exist.'});} }

function outputName(raw) {
  let name;
  try { name = decodeURIComponent(String(raw || '')); } catch (_) { return ''; }
  name = name.replace(/\\/g, '/').split('/').pop();
  name = name.replace(/[<>:"|?*\x00-\x1f]/g, '_').replace(/[. ]+$/g, '');
  if (!name || name === '.' || name === '..' || name.length > 240) return '';
  const stem = name.split('.')[0].toUpperCase();
  if (/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$/.test(stem)) name = '_' + name;
  return name;
}

function cliPath() {
  if (process.env.P3CLI_PATH) return process.env.P3CLI_PATH;
  const platform = process.platform === 'win32' ? 'win32' : (process.platform === 'darwin' ? 'darwin' : 'linux');
  return path.join(ROOT, 'native', 'bin', platform, process.platform === 'win32' ? 'p3cli.exe' : 'p3cli');
}

function runCompressor(executable, source, dir) {
  return new Promise((resolve, reject) => {
    const child = spawn(executable, ['c', source, dir, '-q', '-v', '--replace'], { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let output = '';
    child.stdout.setEncoding('utf8'); child.stderr.setEncoding('utf8');
    child.stdout.on('data', (part) => { if (output.length < 8192) output += part; });
    child.stderr.on('data', (part) => { if (output.length < 8192) output += part; });
    child.once('error', reject);
    child.once('close', (code) => resolve({ code, output }));
  });
}

async function compress(req, res) {
  await authReady;
  const user = sessionUser(req);
  if (!user) return json(res, 401, { error: 'Sign in to compress files.' });
  const name = outputName(req.headers['x-file-name']);
  if (!name) return json(res, 400, { error: 'Send a valid X-File-Name header.' });
  if (/\.3p$/i.test(name)) return json(res, 400, { error: 'This is already a .3p archive.' });
  const length = Number(req.headers['content-length'] || 0);
  if (length > MAX_UPLOAD_BYTES) return json(res, 413, { error: 'Maximum upload size is 1 GB.' });

  if (activeJobs >= MAX_ACTIVE_JOBS) return json(res, 429, { error: 'The compressor is busy. Try again shortly.' });
  activeJobs++;
  let jobDir;
  try {
    const executable = cliPath();
    await fsp.access(executable, fs.constants.X_OK).catch(async (err) => {
      if (process.platform === 'win32' && err.code !== 'ENOENT') return;
      throw err;
    });
    jobDir = await fsp.mkdtemp(path.join(os.tmpdir(), '3pfiles-'));
    const source = path.join(jobDir, name);
    let received = 0;
    const limiter = new Transform({ transform(chunk, enc, done) {
      received += chunk.length;
      if (received > MAX_UPLOAD_BYTES) return done(Object.assign(new Error('Maximum upload size is 1 GB.'), { statusCode: 413 }));
      done(null, chunk);
    } });
    await pipeline(req, limiter, fs.createWriteStream(source, { flags: 'wx' }));
    if (!received) return json(res, 400, { error: 'The uploaded file is empty.' });

    const result = await runCompressor(executable, source, jobDir);
    if (result.code !== 0) {
      const message = /not smaller/i.test(result.output)
        ? 'This file did not compress smaller, so the original was kept.'
        : 'Compression failed. The uploaded original was kept.';
      return json(res, /not smaller/i.test(result.output) ? 422 : 500, { error: message });
    }
    const archivePath = path.join(jobDir, name + '.3p');
    const stats = await fsp.stat(archivePath);
    if (stats.size >= received) return json(res, 422, { error: 'This file did not compress smaller, so the original was kept.' });
    const encodedName = encodeURIComponent(name + '.3p').replace(/['()*]/g, (char) => '%' + char.charCodeAt(0).toString(16).toUpperCase());
    const libraryItem = await storeAccountFile(user, archivePath, name + '.3p', 'compressed', stats.size);
     res.writeHead(200, {
      'Content-Type': 'application/octet-stream',
      'Content-Length': stats.size,
      'Content-Disposition': 'attachment; filename="compressed.3p"; filename*=UTF-8\'\'' + encodedName,
      'X-Original-Bytes': String(received),
      'X-Compressed-Bytes': String(stats.size),
      'X-Output-Name': encodedName,
      'Cache-Control': 'no-store'
    });
    await pipeline(fs.createReadStream(archivePath), res);
  } catch (err) {
    if (res.headersSent) { res.destroy(err); return; }
    if (err.statusCode === 413) return json(res, 413, { error: err.message });
    if (err.code === 'ENOENT') return json(res, 503, { error: 'The native 3P compressor is not installed for this server platform yet.' });
    return json(res, 500, { error: 'Compression service failed.' });
  } finally {
    if (jobDir) await fsp.rm(jobDir, { recursive: true, force: true }).catch(() => {});
    activeJobs--;
  }
}

const server = http.createServer(async (req, res) => {
  try {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname === '/API/v1/auth/providers' && req.method === 'GET') {
    const providers = {}; for (const name of ['google','facebook','apple','discord']) providers[name] = !!providerConfig(name).enabled;
    return json(res, 200, { providers });
  }
  const oauthStart = url.pathname.match(/^\/oauth\/(google|facebook|apple|discord)$/);
  if (oauthStart) { if (req.method !== 'GET') return json(res,405,{error:'Method not allowed.'}); return oauthBegin(req,res,oauthStart[1]); }
  const oauthCallback = url.pathname.match(/^\/oauth\/(google|facebook|apple|discord)\/callback$/);
  if (oauthCallback) { const provider=oauthCallback[1],validMethod=provider==='apple'?'POST':'GET'; if(req.method!==validMethod)return json(res,405,{error:'Method not allowed.'}); return finishOAuth(provider,req,res); }
  if (url.pathname.startsWith('/API/v1/account/files') || url.pathname.startsWith('/API/v1/account/folders')) return accountFilesApi(req,res,url);
  if (url.pathname.startsWith('/API/v1/auth/') || url.pathname === '/API/v1/notifications' || url.pathname === '/API/v1/notifications/read' || url.pathname === '/API/v1/notifications/download') {
    const handled = await authApi(req, res, url.pathname);
    if (handled !== false) return handled;
    return json(res, 405, { error: 'Method not allowed.' });
  }
  if (url.pathname === '/API/v1/extract') {
    if (req.method !== 'POST') return json(res, 405, { error: 'Use POST to uncompress an archive.' });
    return extract(req, res);
  }
  if (url.pathname === '/API/v1/shares') {
    if (req.method !== 'POST') return json(res, 405, { error: 'Use POST to create a share link.' });
    return createShare(req, res);
  }
  const shareMatch = url.pathname.match(/^\/s\/([a-f0-9]{48})$/);
  if (shareMatch) { if (req.method !== 'GET') return json(res, 405, { error: 'Use GET to download this shared archive.' }); return serveShare(res, shareMatch[1]); }
  if (url.pathname === '/API/v1/compress') {
    if (req.method !== 'POST') return json(res, 405, { error: 'Use POST for compression.' });
    return compress(req, res);
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return json(res, 405, { error: 'Method not allowed.' });
  let pathname;
  try { pathname = decodeURIComponent(url.pathname); } catch (_) { return json(res, 400, { error: 'Invalid path.' }); }
  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const filePath = path.resolve(ROOT, relative);
  if (!filePath.startsWith(ROOT_PREFIX)) return json(res, 403, { error: 'Forbidden.' });
  if (relative.split(/[\\/]/).some(part => part.toLowerCase() === '.private')) return json(res, 404, { error: 'Not found.' });
  if (path.basename(relative).toLowerCase().startsWith('.env')) return json(res, 404, { error: 'Not found.' });
  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) return json(res, 404, { error: 'Not found.' });
    res.writeHead(200, { 'Content-Type': MIME_TYPES[path.extname(filePath)] || 'application/octet-stream', 'Content-Length': stats.size });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
  } catch (err) {
    if (!res.headersSent) json(res, err.statusCode || 500, { error: err.statusCode ? err.message : 'Request failed.' });
    else res.destroy(err);
  }
});

server.on('error', err => {
  if (err.code === 'EADDRINUSE') {
    console.error('3Pfiles could not start: port ' + PORT + ' is already in use.');
    console.error('Start another copy with: npm start -- --port 3001');
  } else console.error('3Pfiles server failed to start:', err.message);
  process.exitCode = 1;
});
// Large uploads can take longer than Node's five-minute default request timeout.
server.requestTimeout = 6 * 60 * 60 * 1000;
server.headersTimeout = 65 * 1000;
server.timeout = 0;
server.listen(PORT, () => console.log('3Pfiles native compression service on http://localhost:' + PORT));
module.exports = server;
