#!/usr/bin/env sh
set -eu
NATIVE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OUT="$NATIVE_DIR/bin/darwin"
mkdir -p "$OUT"
clang++ -arch x86_64 -arch arm64 -std=c++17 -O3 -DNDEBUG -pthread "$NATIVE_DIR/src/p3cli.cpp" -o "$OUT/p3cli"
