'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const root = path.resolve(__dirname, '..');
const platform = process.platform === 'win32' ? 'win32' : process.platform === 'darwin' ? 'darwin' : process.platform === 'linux' ? 'linux' : null;
if (!platform) {
  console.error('3Pfiles compression is not supported on this server platform: ' + process.platform);
  process.exit(1);
}

const cli = process.env.P3CLI_PATH
  ? path.resolve(process.env.P3CLI_PATH)
  : path.join(root, 'native', 'bin', platform, platform === 'win32' ? 'p3cli.exe' : 'p3cli');
if (fs.existsSync(cli)) process.exit(0);
if (process.env.P3CLI_PATH) {
  console.error('P3CLI_PATH does not point to an existing compressor executable: ' + cli);
  process.exit(1);
}
if (platform === 'win32') {
  console.error('The Windows compressor is missing. Restore native\\bin\\win32\\p3cli.exe or build it with native\\build-windows.cmd.');
  process.exit(1);
}

const buildScript = platform === 'darwin' ? 'build-macos.sh' : 'build-linux.sh';
const result = spawnSync('/bin/sh', [path.join(root, 'native', buildScript)], { cwd: root, stdio: 'inherit' });
if (result.error) {
  console.error('Could not start the native compressor build:', result.error.message);
  process.exit(1);
}
if (result.status !== 0 || !fs.existsSync(cli)) {
  console.error('Could not build the native compressor. Install a C++17 compiler and retry npm start.');
  process.exit(result.status || 1);
}
console.log('Built the ' + platform + ' 3P compressor at ' + cli);
