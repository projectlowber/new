// engine3p.hpp - the 3P compression engine (portable C++17, header-only).
//
//  .3p file layout
//    [0xB3] [varint nameLen] [name, UTF-8] [varint originalSize] [u8 tableBits] [varint pixelStride] ([u8 bytesPerPixel])
//    then one FRAME per 8 MiB segment of the original:
//    [varint payloadLen*2 + modeled] [crc32 of the original segment, 4 bytes LE] [payload]
//
//  * Segments are independent, so compression AND extraction run on every CPU core.
//  * Inside a modeled segment: 16 KB blocks, each coded by the model, stored raw, or skipped without
//    touching the model (long incompressible runs run ~15x faster than modeled data).
//  * Integer-only model (context mixing + match + SSE): bit-identical on every machine and compiler.
//  * Memory is bounded: one model (~110 MB) + two 8 MB buffers per worker thread; tables are
//    lazily committed (calloc), so small or incompressible inputs touch very little RAM.
#pragma once
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <functional>
#include <memory>
#include <new>
#include <string>
#include <vector>
#ifdef _WIN32
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0601   // Windows 7+: condition variables
#endif
#ifndef WINVER
#define WINVER 0x0601
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <wchar.h>
#else
#include <condition_variable>
#include <mutex>
#include <thread>
#endif

namespace p3 {
namespace fs = std::filesystem;
typedef uint8_t u8; typedef uint16_t u16; typedef uint32_t u32; typedef uint64_t u64;
typedef int16_t i16; typedef int32_t i32; typedef int64_t i64;

constexpr u8 kMagic = 0xB3;
constexpr size_t kSegment = (size_t)8 << 20;    // independent unit of parallel work
constexpr size_t kBlock = 1u << 14;             // model / raw / skip decision granularity
constexpr size_t kMaxName = 1000;
inline const char* extension() { return ".3p"; }

// ------------------------------------------------------------------ public API
enum class Status { Ok, Cancelled, IoError, BadFormat, Corrupt, OutOfMemory, DiskFull, NotSmaller };
struct Result {
    Status status = Status::Ok;
    std::string message;
    u64 inSize = 0, outSize = 0;     // compress: original / .3p size.  restore: .3p / restored size
    fs::path outPath;
    std::string storedName;          // original file name (UTF-8) kept in the metadata
};
struct Options {
    unsigned threads = 0;            // 0 = automatic
    u64 memoryBudget = 0;            // bytes the engine may use for worker models; 0 = no limit
    bool verify = false;             // decode every segment right after encoding it
    bool replaceSource = false;      // replace the source with a verified, smaller .3p archive
    bool dedup = true;               // find long-distance duplicates (any distance) before compressing
    bool detect = true;              // detect headerless PCM audio and fixed-size records / image rows
    fs::path outDir;                 // empty = next to the source file
};
// progress(fractionDone 0..1, outputBytesSoFar). Return false to cancel. Called ~10x per second.
typedef std::function<bool(double, u64)> ProgressFn;

// ------------------------------------------------------------------ platform threading (no std::thread on Windows,
// so there is no dependency on the MinGW threading model)
namespace sys {
#ifdef _WIN32
class Mutex { CRITICAL_SECTION cs_; public:
    Mutex() { InitializeCriticalSection(&cs_); } ~Mutex() { DeleteCriticalSection(&cs_); }
    Mutex(const Mutex&) = delete; Mutex& operator=(const Mutex&) = delete;
    void lock() { EnterCriticalSection(&cs_); } void unlock() { LeaveCriticalSection(&cs_); } CRITICAL_SECTION* native() { return &cs_; } };
class CondVar { CONDITION_VARIABLE cv_; public:
    CondVar() { InitializeConditionVariable(&cv_); }
    CondVar(const CondVar&) = delete; CondVar& operator=(const CondVar&) = delete;
    void notify_all() { WakeAllConditionVariable(&cv_); }
    void wait(Mutex& m) { SleepConditionVariableCS(&cv_, m.native(), INFINITE); }
    void wait_ms(Mutex& m, unsigned ms) { SleepConditionVariableCS(&cv_, m.native(), ms); } };
class Thread { HANDLE h_ = nullptr; std::function<void()> fn_;
    static DWORD WINAPI tramp(LPVOID p) { static_cast<Thread*>(p)->fn_(); return 0; }
public:
    Thread() {} Thread(const Thread&) = delete; Thread& operator=(const Thread&) = delete;
    bool start(std::function<void()> f) { fn_ = std::move(f); h_ = CreateThread(nullptr, 0, tramp, this, 0, nullptr); return h_ != nullptr; }
    void join() { if (h_) { WaitForSingleObject(h_, INFINITE); CloseHandle(h_); h_ = nullptr; } }
    ~Thread() { join(); } };
inline unsigned hardware_threads() { SYSTEM_INFO si; GetSystemInfo(&si); return si.dwNumberOfProcessors ? (unsigned)si.dwNumberOfProcessors : 1u; }
#else
class Mutex { std::mutex m_; public: void lock() { m_.lock(); } void unlock() { m_.unlock(); } };
class CondVar { std::condition_variable_any cv_; public:
    void notify_all() { cv_.notify_all(); }
    void wait(Mutex& m) { cv_.wait(m); }
    void wait_ms(Mutex& m, unsigned ms) { cv_.wait_for(m, std::chrono::milliseconds(ms)); } };
class Thread { std::thread t_; public:
    bool start(std::function<void()> f) { try { t_ = std::thread(std::move(f)); return true; } catch (...) { return false; } }
    void join() { if (t_.joinable()) t_.join(); } ~Thread() { join(); } };
inline unsigned hardware_threads() { unsigned n = std::thread::hardware_concurrency(); return n ? n : 1u; }
#endif
struct Lock { Mutex& m; explicit Lock(Mutex& mm) : m(mm) { m.lock(); } ~Lock() { m.unlock(); } };
}  // namespace sys

// ------------------------------------------------------------------ internals
namespace detail {

struct Failure { Status status; std::string msg; };
struct Cancelled {};

inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline int ceil_log2(u64 x) { int k = 0; while (k < 63 && ((u64)1 << k) < x) k++; return k; }

template <class T> struct Arr {                  // zero-initialised, lazily committed by the OS
    T* p = nullptr;
    Arr() {} Arr(const Arr&) = delete; Arr& operator=(const Arr&) = delete;
    void alloc(size_t n) { std::free(p); p = (T*)std::calloc(n ? n : 1, sizeof(T)); if (!p) throw std::bad_alloc(); }
    ~Arr() { std::free(p); }
    T& operator[](size_t i) { return p[i]; }
};

struct Tables {
    short stretch_[4096]; int dt_[1024]; double lg1_[4097];
    static int squash(int d) {
        static const int t[33] = {1,2,3,6,10,16,27,45,73,120,194,310,488,747,1101,1546,2047,
            2549,2994,3348,3607,3785,3901,3975,4022,4050,4068,4079,4085,4089,4092,4093,4094};
        if (d > 2047) return 4095;
        if (d < -2047) return 0;
        int w = d & 127; d = (d >> 7) + 16;
        return (t[d] * (128 - w) + t[d + 1] * w + 64) >> 7;
    }
    Tables() {
        int pi = 0;
        for (int x = -2047; x <= 2047; x++) { int v = squash(x); for (int i = pi; i <= v; i++) stretch_[i] = (short)x; pi = v + 1; }
        for (int i = pi; i < 4096; i++) stretch_[i] = 2047;
        for (int i = 0; i < 1024; i++) dt_[i] = 16384 / (i + i + 3);
        for (int i = 1; i < 4096; i++) lg1_[i] = -std::log((double)i / 4096.0) / std::log(2.0);   // encoder-only decision aid
        lg1_[0] = lg1_[4096] = 12.0;
    }
};
inline const Tables g_tables;
inline const Tables& tables() { return g_tables; }
inline int squash(int d) { return Tables::squash(d); }

constexpr u32 kInit = 0x80000000u;               // counters are stored XOR kInit so zeroed memory means p=0.5, n=0
inline void sm_up(u32* t, int y, int limit) {
    const Tables& T = tables();
    int n = (int)(*t & 1023), p = (int)(*t >> 10);
    if (n < limit) ++*t; else *t = (*t & 0xfffffc00u) | (u32)limit;
    i64 d = (((i64)(y << 22) - p) >> 3) * T.dt_[n];
    *t = (u32)((i64)*t + (d & ~(i64)1023));
}
inline u32 hmix(u32 h, u32 v) {
    h ^= v + 0x9E3779B9u + (h << 6) + (h >> 2);
    h *= 0x85EBCA6Bu; h ^= h >> 15; h *= 0xC2B2AE35u; h ^= h >> 13;
    return h;
}

struct APM {
    std::vector<u16> t; int idx = 0;
    void init(int n) {
        t.resize((size_t)n * 24); idx = 0;
        for (int i = 0; i < n; i++) for (int j = 0; j < 24; j++) t[(size_t)i * 24 + j] = (u16)(squash(((j * 2 + 1) * 4096) / 48 - 2048) * 16);
    }
    int pp(int pr, int cx) {
        int s = (tables().stretch_[pr] + 2048) * 23, wt = s & 0xfff;
        cx = cx * 24 + (s >> 12); idx = cx + (wt >> 11);
        return (t[cx] * (4096 - wt) + t[cx + 1] * wt) >> 16;
    }
    void up(int y) { int g = (y << 16) + (y << 7) - y - y; t[idx] = (u16)(t[idx] + ((g - t[idx]) >> 7)); }
};

// ------------------------------------------------------------------ what the model is told about the data
// PCM WAV audio (8/16/24-bit, 1-8 channels): the "data" chunk is turned into prediction residuals before modelling.
struct Audio {
    u64 dataOff = 0, dataLen = 0; int channels = 0, width = 0;
    bool on() const { return channels > 0; }
    int frame() const { return channels * width; }
};
// whole audio frames of segment [segStart, segStart+L) as local offsets [ts, te); empty region -> ts == te == 0
inline void audio_region(const Audio& a, u64 segStart, size_t L, size_t& ts, size_t& te) {
    ts = te = 0; if (!a.on()) return;
    u64 f = (u64)a.frame(), e = segStart + L;
    u64 lo = std::max(segStart, a.dataOff), hi = std::min(e, a.dataOff + a.dataLen);
    if (hi <= lo) return;
    u64 rel = (lo - a.dataOff) % f; if (rel) lo += f - rel;
    if (lo >= hi) return;
    hi = lo + ((hi - lo) / f) * f; if (hi <= lo) return;
    ts = (size_t)(lo - segStart); te = (size_t)(hi - segStart);
}
struct Hint {                                       // per-segment hints for the model contexts
    int stride = 0, bpp = 0;                        // BMP pixel geometry
    u64 ats = 0, ate = 0; int channels = 0, width = 0;   // audio residual region (local offsets)
};

// ------------------------------------------------------------------ the model
class Model {
public:
    static constexpr int NBIT = 5, NBYTE = 9, NCTX = NBIT + NBYTE, N_IN = NCTX + 2;
    static constexpr int MINLEN = 4, LIMIT = 30, LR1 = 32, LR2 = 4, BIAS = 77;

    Model(u64 len, int tbMax, const Hint& hint) {
        byteTb_ = clampi(ceil_log2(len ? len * 8 : 1) + 1, 16, tbMax);
        mtBits_ = clampi(ceil_log2(len ? len : 1) + 1, 12, tbMax);
        u64 w = 4096; while (w < len && w < ((u64)1 << 24)) w <<= 1;
        ring_ = (size_t)w; mask_ = w - 1;
        static const int ords[NBIT] = {2, 4, 8, 12, 16};
        for (int i = 0; i < NCTX; i++) tab_[i].alloc((size_t)1 << (i < NBIT ? ords[i] : byteTb_));
        buf_.alloc(ring_); mtab_.alloc((size_t)1 << mtBits_);
        for (int i = 0; i < 32; i++) mm_[i] = kInit;
        mix1_.assign((size_t)256 * N_IN, 9830); mix2_.assign((size_t)216 * N_IN, 9830); mix3_.assign((size_t)256 * N_IN, 9830);
        for (int i = 0; i < 8; i++) for (int j = 0; j < 4; j++) mixf_[i][j] = 21845;
        a1_.init(256); a2_.init(65536);
        if (hint.stride > 0 && hint.bpp > 0 && (u64)hint.stride + (u64)hint.bpp + 8 < ring_ / 2) { stride_ = hint.stride; bpp_ = hint.bpp; }
        if (hint.channels > 0 && hint.width > 0 && hint.ate > hint.ats) { ats_ = hint.ats; ate_ = hint.ate; ach_ = hint.channels; aw_ = hint.width; }
        setByteCtx();
    }

    int predict() {
        const Tables& T = tables();
        static const int ords[NBIT] = {2, 4, 8, 12, 16};
        for (int i = 0; i < NBIT; i++) slot_[i] = &tab_[i][hist_ & ((1u << ords[i]) - 1)];
        if (pos_ == 0 || pos_ == 4)                       // one cache line (16 counters) per nibble context
            for (int i = 0; i < NBYTE; i++) base_[i] = (hmix(bh_[i], pos_ == 0 ? 0u : c0_) >> (32 - byteTb_)) & ~15u;
        int j = pos_ & 3;
        u32 nib = j == 0 ? 1u : ((1u << j) | (c0_ & ((1u << j) - 1)));
        for (int i = 0; i < NBYTE; i++) slot_[NBIT + i] = &tab_[NBIT + i][base_[i] + nib];
        for (int i = 0; i < NCTX; i++) {
            u32 t = *slot_[i] ^ kInit;
            st_[i] = (t & 1023) ? T.stretch_[clampi((int)(t >> 20), 4, 4091)] : 0;
        }
        mctx_ = 0; mexp_ = -1; st_[NCTX] = 0;
        if (mptr_) {
            u32 pb = (u32)buf_[(size_t)(mptr_ & mask_)] | 256u;
            if ((pb >> (8 - pos_)) == c0_) {
                mexp_ = (int)((pb >> (7 - pos_)) & 1);
                mctx_ = 1 + (int)(mlen_ < 30 ? mlen_ : 30);
                int s = T.stretch_[clampi((int)(mm_[mctx_] >> 20), 41, 4055)];
                st_[NCTX] = mexp_ ? s : -s;
            }
        }
        st_[NCTX + 1] = BIAS;
        int mb = mexp_ < 0 ? 0 : 1 + (int)((mlen_ < 15 ? mlen_ : 15) / 2);
        wsel_[0] = &mix1_[(size_t)c0_ * N_IN];
        wsel_[1] = &mix2_[(size_t)(((mb * 3) + (mexp_ + 1)) * 8 + pos_) * N_IN];
        wsel_[2] = &mix3_[(size_t)c1_ * N_IN];
        for (int k = 0; k < 3; k++) {
            i64 s = 0;
            for (int i = 0; i < N_IN; i++) s += (i64)wsel_[k][i] * st_[i];
            int d = clampi((int)(s >> 16), -2047, 2047);
            p1_[k] = squash(d); st2_[k] = d;
        }
        st2_[3] = BIAS;
        i64 s = 0;
        for (int i = 0; i < 4; i++) s += (i64)mixf_[pos_][i] * st2_[i];
        int d = clampi((int)(s >> 16), -2047, 2047);
        pf_ = clampi(squash(d), 1, 4095);
        int a1 = a1_.pp(pf_, (int)c0_), a2 = a2_.pp(pf_, (int)((c1_ << 8) | c0_));
        return clampi((2 * pf_ + a1 + a2 + 2) >> 2, 1, 4095);
    }

    void update(int y) {
        for (int k = 0; k < 3; k++) {
            int e0 = (y << 12) - p1_[k];
            if (e0 > 6 || e0 < -6) {
                int err = e0 * LR1;
                for (int i = 0; i < N_IN; i++) wsel_[k][i] += (st_[i] * err + 0x8000) >> 16;
            }
        }
        int err = ((y << 12) - pf_) * LR2;
        for (int i = 0; i < 4; i++) mixf_[pos_][i] += (st2_[i] * err + 0x8000) >> 16;
        a1_.up(y); a2_.up(y);
        for (int i = 0; i < NCTX; i++) { u32 t = *slot_[i] ^ kInit; sm_up(&t, y, LIMIT); *slot_[i] = t ^ kInit; }
        if (mexp_ >= 0) sm_up(&mm_[mctx_], y == mexp_, 60);
        hist_ = (hist_ << 1) | (u32)y;
        c0_ = (c0_ << 1) | (u32)y;
        if (++pos_ == 8) byteDone(c0_ & 255u);
    }

private:
    static u32 bitlen(u32 v) { u32 n = 0; while (v) { n++; v >>= 1; } return n; }
    int resAt(u64 idx) const {                            // signed residual stored at absolute index idx (aw_ bytes, little endian)
        u32 v = 0; for (int i = aw_ - 1; i >= 0; i--) v = (v << 8) | buf_.p[(size_t)((idx + (u64)i) & mask_)];
        int bits = 8 * aw_; return (int)((v ^ (1u << (bits - 1))) - (1u << (bits - 1)));
    }
    int back(u32 k) const { return (k && blen_ >= k) ? buf_.p[(size_t)((blen_ - k) & mask_)] : 0; }

    void setByteCtx() {
        u32 h;
        bh_[0] = hmix(0xA0, 0);
        h = hmix(0xA1, c1_);     bh_[1] = h;
        h = hmix(h ^ 0xA2, c2_); bh_[2] = h;
        h = hmix(h ^ 0xA3, c3_); bh_[3] = h;
        h = hmix(h ^ 0xA4, c4_); bh_[4] = h;
        bh_[5] = hmix(0xA5, word_);
        if (blen_ >= ats_ && blen_ < ate_ && ach_) {      // audio residuals: magnitude contexts of neighbouring samples
            u64 f = (u64)(ach_ * aw_), rel = (blen_ - ats_) % f, base = blen_ - (rel % (u64)aw_);
            int bi = (int)(rel % (u64)aw_);
            int p1 = base >= ats_ + f ? resAt(base - f) : 0, p2 = base >= ats_ + 2 * f ? resAt(base - 2 * f) : 0;
            int ot = base >= ats_ + (u64)aw_ ? resAt(base - (u64)aw_) : 0;
            u32 q1 = bitlen(p1 < 0 ? -p1 : p1), q2 = bitlen(p2 < 0 ? -p2 : p2), qo = bitlen(ot < 0 ? -ot : ot);
            u32 known = bi ? (u32)back(1) | (bi > 1 ? (u32)back(2) << 8 : 0u) : 0u;       // bytes of this sample already coded
            u32 avg = bitlen((u32)(((p1 < 0 ? -p1 : p1) + (p2 < 0 ? -p2 : p2) + (ot < 0 ? -ot : ot)) / 3));
            bh_[6] = hmix(hmix(0xD0, (u32)rel), q1 | (q2 << 6) | (known >> 4 << 12));
            bh_[7] = hmix(hmix(hmix(0xD1, (u32)rel), qo), known);
            bh_[8] = hmix(hmix(0xD2, (u32)rel), avg | (q1 << 6) | (qo << 12));
        } else if (stride_) {                             // BMP pixels: left / above / above-left neighbours
            int l = back((u32)bpp_), a = back((u32)stride_), al = back((u32)(stride_ + bpp_));
            bh_[6] = hmix(hmix(0xB0, (u32)a), (u32)l);
            bh_[7] = hmix(0xB1, (u32)clampi(l + a - al, 0, 255));
            bh_[8] = hmix(hmix(0xB2, (u32)a), c1_);
        } else {                                          // sparse "skip" contexts
            bh_[6] = hmix(0xC0, c2_);
            bh_[7] = hmix(hmix(0xC1, c2_), c3_);
            bh_[8] = hmix(hmix(0xC2, c1_), c3_);
        }
    }

    void byteDone(u32 c) {
        pos_ = 0; c0_ = 1;
        c4_ = c3_; c3_ = c2_; c2_ = c1_; c1_ = c;
        if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122) || (c >= 48 && c <= 57)) word_ = (word_ * 263u + c + 1u) & 0xFFFFFFu; else word_ = 0;
        buf_[(size_t)(blen_ & mask_)] = (u8)c; blen_++;
        if (mptr_ && buf_[(size_t)(mptr_ & mask_)] == c) { mlen_++; mptr_++; } else { mlen_ = 0; mptr_ = 0; }
        if (blen_ >= (u64)MINLEN) {
            u32 h = hmix(hmix(hmix((u32)back(1), (u32)back(2)), (u32)back(3)), (u32)back(4)) >> (32 - mtBits_);
            if (mptr_ == 0) {
                u32 cand = mtab_[h];
                if (cand) {
                    u32 dist = (u32)blen_ - cand;
                    if (dist > 0 && (u64)dist + 40 < ring_) {
                        u64 candAbs = blen_ - dist; u32 l = 0;
                        while (l < 32 && candAbs > l && buf_[(size_t)((candAbs - 1 - l) & mask_)] == buf_[(size_t)((blen_ - 1 - l) & mask_)]) l++;
                        if (l >= (u32)MINLEN) { mptr_ = candAbs; mlen_ = l; }
                    }
                }
            }
            mtab_[h] = (u32)blen_;
        }
        setByteCtx();
    }

    int byteTb_ = 22, mtBits_ = 22;
    size_t ring_ = 4096; u64 mask_ = 4095;
    Arr<u32> tab_[NCTX]; u32* slot_[NCTX] = {}; u32 base_[NBYTE] = {};
    u32 hist_ = 0, c0_ = 1, c1_ = 0, c2_ = 0, c3_ = 0, c4_ = 0, word_ = 0, bh_[NBYTE] = {};
    int pos_ = 0, stride_ = 0, bpp_ = 0;
    u64 ats_ = 0, ate_ = 0; int ach_ = 0, aw_ = 0;
    Arr<u8> buf_; u64 blen_ = 0; Arr<u32> mtab_; u64 mptr_ = 0; u32 mlen_ = 0; u32 mm_[32]; int mexp_ = -1, mctx_ = 0;
    std::vector<i32> mix1_, mix2_, mix3_; i32 mixf_[8][4]; i32* wsel_[3] = {};
    int st_[N_IN] = {}, st2_[4] = {}, p1_[3] = {}, pf_ = 2048;
    APM a1_, a2_;
};

// ------------------------------------------------------------------ audio predictor (integer only, bit-exact everywhere)
// Per channel: stage A = normalised LMS over the last `na` sample differences (+`mc` differences of the other channel;
// for the 2nd channel that includes the current sample of the 1st), stage B = a small LMS over stage A's past errors.
// Three presets trade adaptation speed against precision; the encoder picks the best one per segment.
// forward(): samples -> residuals (same byte count).   inverse(): residuals -> samples.
struct AudioPreset { int na, mc, sha, shb; };
inline const AudioPreset& audio_preset(int i) {
    static const AudioPreset t[3] = {{32, 16, 8, 6}, {32, 8, 7, 5}, {16, 8, 6, 5}};
    return t[i < 0 ? 0 : (i > 2 ? 2 : i)];
}
class AudioCodec {
public:
    static constexpr int NAX = 32, MCX = 16, NB = 16;
    AudioCodec(int channels, int width, int preset) : C_(channels), W_(width), P_(audio_preset(preset)), ch_((size_t)channels) {}
    void forward(u8* p, size_t frames) {
        for (size_t f = 0; f < frames; f++) for (int c = 0; c < C_; c++) {
            int x = getSample(p), pr = predict(c);
            putRes(p, wrap(x - pr)); update(c, x); p += W_;
        }
    }
    void inverse(u8* p, size_t frames) {
        for (size_t f = 0; f < frames; f++) for (int c = 0; c < C_; c++) {
            int r = getRes(p), pr = predict(c), x = wrap(r + pr);
            putSample(p, x); update(c, x); p += W_;
        }
    }
private:
    struct Ch {
        i32 dh[NAX] = {}, eh[NB] = {}, wa[NAX + MCX] = {}, wb[NB] = {}, ia[NAX + MCX] = {};
        i32 s1 = 0, pA = 0, pB = 0; i64 eA = 0, eB = 0;
    };
    int wrap(i64 v) const { int bits = 8 * W_; i64 m = ((i64)1 << bits) - 1; v &= m; if (v >= ((i64)1 << (bits - 1))) v -= ((i64)1 << bits); return (int)v; }
    int getRes(const u8* p) const { u32 v = 0; for (int i = W_ - 1; i >= 0; i--) v = (v << 8) | p[i]; int bits = 8 * W_; return (int)((v ^ (1u << (bits - 1))) - (1u << (bits - 1))); }
    void putRes(u8* p, int r) const { u32 v = (u32)r; for (int i = 0; i < W_; i++) { p[i] = (u8)v; v >>= 8; } }
    int getSample(const u8* p) const { return W_ == 1 ? (int)p[0] - 128 : getRes(p); }
    void putSample(u8* p, int x) const { if (W_ == 1) p[0] = (u8)(x + 128); else putRes(p, x); }
    int predict(int c) {
        Ch& s = ch_[(size_t)c]; const int na = P_.na, m = C_ == 2 ? P_.mc : 0;
        const Ch* o = C_ == 2 ? &ch_[(size_t)(1 - c)] : nullptr;
        for (int i = 0; i < na; i++) s.ia[i] = s.dh[i];
        for (int i = 0; i < m; i++) s.ia[na + i] = o->dh[i];
        i64 sa = 0, ea = 0;
        for (int i = 0; i < na + m; i++) { sa += (i64)s.wa[i] * s.ia[i]; ea += (i64)s.ia[i] * s.ia[i]; }
        s.eA = ea; s.pA = (int)((sa + 32768) >> 16);
        i64 sb = 0, eb = 0;
        for (int i = 0; i < NB; i++) { sb += (i64)s.wb[i] * s.eh[i]; eb += (i64)s.eh[i] * s.eh[i]; }
        s.eB = eb; s.pB = (int)((sb + 32768) >> 16);
        i64 pr = (i64)s.s1 + s.pA + s.pB, lo = -((i64)1 << (8 * W_ - 1)), hi = ((i64)1 << (8 * W_ - 1)) - 1;
        return (int)(pr < lo ? lo : (pr > hi ? hi : pr));
    }
    void update(int c, int x) {
        Ch& s = ch_[(size_t)c]; const int na = P_.na, m = C_ == 2 ? P_.mc : 0;
        int d = x - s.s1, errA = d - s.pA, errB = errA - s.pB;
        const i64 kEps = 2048, kMaxW = (i64)1 << 24;
        i64 g = ((i64)errA * ((i64)1 << (32 - P_.sha))) / (s.eA + kEps);
        for (int i = 0; i < na + m; i++) { i64 w = s.wa[i] + ((g * s.ia[i]) >> 16); s.wa[i] = (i32)(w > kMaxW ? kMaxW : (w < -kMaxW ? -kMaxW : w)); }
        i64 g2 = ((i64)errB * ((i64)1 << (32 - P_.shb))) / (s.eB + kEps);
        for (int i = 0; i < NB; i++) { i64 w = s.wb[i] + ((g2 * s.eh[i]) >> 16); s.wb[i] = (i32)(w > kMaxW ? kMaxW : (w < -kMaxW ? -kMaxW : w)); }
        std::memmove(s.dh + 1, s.dh, (size_t)(na - 1) * sizeof(i32)); s.dh[0] = d;
        std::memmove(s.eh + 1, s.eh, (NB - 1) * sizeof(i32)); s.eh[0] = errA;
        s.s1 = x;
    }
    int C_, W_; AudioPreset P_; std::vector<Ch> ch_;
};

// ------------------------------------------------------------------ arithmetic coder over memory buffers
class Enc {
public:
    explicit Enc(std::vector<u8>& o) : out_(o) {}
    void bit(int y, int p) { u32 xm = x1_ + ((x2_ - x1_) >> 12) * (u32)p; if (y) x2_ = xm; else x1_ = xm + 1; norm(); }
    void half(int y) { u32 xm = x1_ + ((x2_ - x1_) >> 1); if (y) x2_ = xm; else x1_ = xm + 1; norm(); }
    void finish() {                                         // shortest byte string (zero padded by the decoder) inside [x1,x2]
        if (x1_ == 0) return;
        for (int nb = 1; nb <= 4; nb++) {
            int shift = 32 - 8 * nb;
            u64 v = (((u64)x1_ + ((u64)1 << shift) - 1) >> shift) << shift;
            if (v <= x2_) { for (int k = 0; k < nb; k++) out_.push_back((u8)(v >> (24 - 8 * k))); return; }
        }
        for (int k = 0; k < 4; k++) out_.push_back((u8)(x1_ >> (24 - 8 * k)));
    }
private:
    void norm() { while (((x1_ ^ x2_) & 0xff000000u) == 0) { out_.push_back((u8)(x2_ >> 24)); x1_ <<= 8; x2_ = (x2_ << 8) | 255u; } }
    std::vector<u8>& out_; u32 x1_ = 0, x2_ = 0xffffffffu;
};
class Dec {
public:
    Dec(const u8* p, size_t n) : p_(p), n_(n) { for (int i = 0; i < 4; i++) x_ = (x_ << 8) | next(); }
    int bit(int p) { u32 xm = x1_ + ((x2_ - x1_) >> 12) * (u32)p; int y = x_ <= xm; if (y) x2_ = xm; else x1_ = xm + 1; norm(); return y; }
    int half() { u32 xm = x1_ + ((x2_ - x1_) >> 1); int y = x_ <= xm; if (y) x2_ = xm; else x1_ = xm + 1; norm(); return y; }
private:
    u8 next() { return pos_ < n_ ? p_[pos_++] : 0; }
    void norm() { while (((x1_ ^ x2_) & 0xff000000u) == 0) { x1_ <<= 8; x2_ = (x2_ << 8) | 255u; x_ = (x_ << 8) | next(); } }
    const u8* p_; size_t n_, pos_ = 0; u32 x1_ = 0, x2_ = 0xffffffffu, x_ = 0;
};

inline void put_varint_mem(std::vector<u8>& v, u64 n) { while (n >= 128) { v.push_back((u8)(n | 128)); n >>= 7; } v.push_back((u8)n); }

struct Counters { std::atomic<u64> done{0}, out{0}; std::atomic<bool> cancel{false}; };

// order-0 entropy of a block in bits per byte (encoder-side heuristic only, never affects decoding)
inline double block_entropy(const u8* p, size_t n) {
    u32 c[256]; std::memset(c, 0, sizeof c);
    for (size_t i = 0; i < n; i++) c[p[i]]++;
    double s = 0;
    for (int i = 0; i < 256; i++) if (c[i]) s += (double)c[i] * std::log2((double)c[i]);
    return std::log2((double)n) - s / (double)n;
}

// ------------------------------------------------------------------ segment codec
// Block types: 0 = coded by the model, 1 = stored raw inside the arithmetic stream (model still learns),
// 2 = SKIPPED: the model is not run at all and the bytes go to a plain side area (memcpy speed).
// After 4 raw blocks in a row the encoder skips 15 blocks, then probes one block with the model again;
// repeated failed probes lengthen the skip up to 255 blocks (4 MB); a block whose byte entropy drops below 7.7 bits ends it at once.
// payload = [varint arithLen] [arithmetic stream] [bytes of the skipped blocks, in order]
inline void encode_segment(const u8* data, size_t L, int tbMax, const Hint& hint, std::vector<u8>& out, Counters& cn) {
    const Tables& T = tables();
    std::vector<u8> arith, side; arith.reserve(L / 2 + 64);
    Enc e(arith);
    Model m(L, tbMax, hint);
    std::vector<u16> pk(kBlock * 8);
    u32 fcRaw[3] = {kInit, kInit, kInit}, fcSkip[2] = {kInit, kInit};
    int prevType = 0, rawRun = 0, skipLeft = 0, skipLen = 15; size_t off = 0, lastOut = 0;
    while (off < L) {
        if (cn.cancel.load(std::memory_order_relaxed)) throw Cancelled();
        size_t B = std::min(kBlock, L - off); int type; size_t k = 0;
        if (skipLeft > 0 && block_entropy(data + off, B) < 7.7) { skipLeft = 0; rawRun = 0; skipLen = 15; }   // obvious structure: stop skipping
        if (skipLeft > 0) { type = 2; skipLeft--; }
        else {
            double cost = 0;
            for (size_t i = 0; i < B; i++) {
                u32 byte = data[off + i];
                for (int b = 7; b >= 0; b--) {
                    int y = (byte >> b) & 1, p = m.predict();
                    cost += y ? T.lg1_[p] : T.lg1_[4096 - p];
                    pk[k++] = (u16)((p << 1) | y);
                    m.update(y);
                }
            }
            type = cost + 0.5 >= 8.0 * (double)B ? 1 : 0;
            if (type) { if (++rawRun >= 4) { skipLeft = skipLen; skipLen = std::min(skipLen * 2 + 1, 255); } }
            else { rawRun = 0; skipLen = 15; }
        }
        e.bit(type != 0, clampi((int)(fcRaw[prevType] >> 20), 16, 4080)); sm_up(&fcRaw[prevType], type != 0, 30);
        if (type) { int c = prevType == 2; e.bit(type == 2, clampi((int)(fcSkip[c] >> 20), 16, 4080)); sm_up(&fcSkip[c], type == 2, 30); }
        prevType = type;
        if (type == 0) for (size_t j = 0; j < k; j++) e.bit(pk[j] & 1, pk[j] >> 1);
        else if (type == 1) for (size_t j = 0; j < k; j++) e.half(pk[j] & 1);
        else side.insert(side.end(), data + off, data + off + B);
        off += B;
        cn.done.fetch_add(B, std::memory_order_relaxed);
        size_t now = arith.size() + side.size();
        cn.out.fetch_add(now - lastOut, std::memory_order_relaxed); lastOut = now;
    }
    e.finish();
    cn.out.fetch_add(arith.size() + side.size() - lastOut, std::memory_order_relaxed);
    out.clear(); put_varint_mem(out, arith.size());
    out.insert(out.end(), arith.begin(), arith.end()); out.insert(out.end(), side.begin(), side.end());
}

inline void decode_segment(const u8* payload, size_t plen, u8* out, size_t L, int tbMax, const Hint& hint, Counters* cn) {
    u64 alen = 0; size_t hdr = 0; int shift = 0;
    for (;;) { if (hdr >= plen || shift > 56) throw Failure{Status::Corrupt, "file is damaged (segment header)"};
               u8 c = payload[hdr++]; alen |= (u64)(c & 127) << shift; if (!(c & 128)) break; shift += 7; }
    if (alen > plen - hdr) throw Failure{Status::Corrupt, "file is damaged (segment size)"};
    Dec d(payload + hdr, (size_t)alen);
    const u8* side = payload + hdr + alen; size_t sideLeft = plen - hdr - (size_t)alen;
    Model m(L, tbMax, hint);
    u32 fcRaw[3] = {kInit, kInit, kInit}, fcSkip[2] = {kInit, kInit};
    int prevType = 0; size_t off = 0;
    while (off < L) {
        if (cn && cn->cancel.load(std::memory_order_relaxed)) throw Cancelled();
        size_t B = std::min(kBlock, L - off);
        int type = d.bit(clampi((int)(fcRaw[prevType] >> 20), 16, 4080)); sm_up(&fcRaw[prevType], type, 30);
        if (type) { int c = prevType == 2; int sk = d.bit(clampi((int)(fcSkip[c] >> 20), 16, 4080)); sm_up(&fcSkip[c], sk, 30); type = sk ? 2 : 1; }
        prevType = type;
        u8* o = out + off;
        if (type == 2) {
            if (sideLeft < B) throw Failure{Status::Corrupt, "file is damaged (missing data)"};
            std::memcpy(o, side, B); side += B; sideLeft -= B;
        } else for (size_t i = 0; i < B; i++) {
            int v = 0;
            for (int b = 0; b < 8; b++) { int p = m.predict(), y = type ? d.half() : d.bit(p); m.update(y); v = (v << 1) | y; }
            o[i] = (u8)v;
        }
        off += B;
        if (cn) { cn->done.fetch_add(B, std::memory_order_relaxed); cn->out.fetch_add(B, std::memory_order_relaxed); }
    }
}

// ------------------------------------------------------------------ helpers
struct Crc {
    u32 t[8][256];
    Crc() {
        for (u32 i = 0; i < 256; i++) { u32 c = i; for (int k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : c >> 1; t[0][i] = c; }
        for (u32 i = 0; i < 256; i++) for (int k = 1; k < 8; k++) t[k][i] = (t[k - 1][i] >> 8) ^ t[0][t[k - 1][i] & 255];
    }
};
inline const Crc g_crc;
inline u32 crc32_update(u32 prev, const u8* p, size_t n) {
    const Crc& C = g_crc; u32 r = ~prev;
    while (n >= 8) {
        u32 a = r ^ ((u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24));
        r = C.t[7][a & 255] ^ C.t[6][(a >> 8) & 255] ^ C.t[5][(a >> 16) & 255] ^ C.t[4][a >> 24] ^
            C.t[3][p[4]] ^ C.t[2][p[5]] ^ C.t[1][p[6]] ^ C.t[0][p[7]];
        p += 8; n -= 8;
    }
    while (n--) r = C.t[0][(r ^ *p++) & 255] ^ (r >> 8);
    return ~r;
}
inline u32 crc32(const u8* p, size_t n) { return crc32_update(0, p, n); }

inline FILE* fopen_path(const fs::path& p, const char* mode) {
#ifdef _WIN32
    std::wstring m(mode, mode + std::strlen(mode)); return _wfopen(p.c_str(), m.c_str());
#else
    return std::fopen(p.c_str(), mode);
#endif
}
inline int seek64(FILE* f, u64 off) {
#ifdef _WIN32
    return _fseeki64(f, (__int64)off, SEEK_SET);
#else
    return fseeko(f, (off_t)off, SEEK_SET);
#endif
}
struct File {
    FILE* f = nullptr; File() {} File(const File&) = delete; File& operator=(const File&) = delete;
    bool open(const fs::path& p, const char* mode) { close(); f = fopen_path(p, mode); return f != nullptr; }
    void close() { if (f) { std::fclose(f); f = nullptr; } } ~File() { close(); }
};
inline std::string to_utf8(const fs::path& p) { auto s = p.u8string(); return std::string(s.begin(), s.end()); }
inline fs::path from_utf8(const std::string& s) {
#if defined(__cpp_char8_t)
    return fs::path(std::u8string(s.begin(), s.end()));
#else
    return fs::u8path(s);
#endif
}
inline std::string safe_name(std::string n) {            // never trust a name that came out of a file
    size_t cut = n.find_last_of("/\\"); if (cut != std::string::npos) n = n.substr(cut + 1);
    for (char& c : n) if ((unsigned char)c < 32 || std::strchr("<>:\"|?*", c)) c = '_';
    while (!n.empty() && (n.back() == '.' || n.back() == ' ')) n.pop_back();
    if (n.empty()) n = "restored_file";
    std::string up; for (char c : n.substr(0, n.find('.'))) up += (char)std::toupper((unsigned char)c);
    static const char* bad[] = {"CON","PRN","AUX","NUL","COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9","LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9"};
    for (const char* b : bad) if (up == b) { n = "_" + n; break; }
    if (n.size() > 200) { size_t dot = n.rfind('.'); std::string ext = (dot != std::string::npos && n.size() - dot < 20) ? n.substr(dot) : ""; n = n.substr(0, 200 - ext.size()) + ext; }
    return n;
}
inline fs::path unique_path(const fs::path& dir, const std::string& name) {
    fs::path base = from_utf8(name), p = dir / base; std::error_code ec;
    if (!fs::exists(p, ec)) return p;
    std::string stem = to_utf8(base.stem()), ext = to_utf8(base.extension());
    for (int i = 1; i < 100000; i++) { p = dir / from_utf8(stem + " (" + std::to_string(i) + ")" + ext); if (!fs::exists(p, ec)) return p; }
    return dir / base;
}
inline void put_varint(std::vector<u8>& v, u64 n) { while (n >= 128) { v.push_back((u8)(n | 128)); n >>= 7; } v.push_back((u8)n); }
inline bool get_varint(FILE* f, u64& n, u64& used) {
    n = 0; int shift = 0;
    for (;;) { int c = std::fgetc(f); if (c == EOF || shift > 63) return false; used++; n |= (u64)(c & 127) << shift; if (!(c & 128)) return true; shift += 7; }
}
struct Match { u64 gap = 0, len = 0, dist = 0; };   // gap = literal bytes since the previous match; copy len bytes from dist back
struct Header { std::string name; u64 total = 0; int tbMax = 22, stride = 0, bpp = 0; Audio audio; u64 bytes = 0;
                bool dedup = false; u32 fileCrc = 0; u64 litTotal = 0; std::vector<Match> matches; };
inline std::vector<u8> make_header(const Header& h) {
    std::vector<u8> v; v.push_back(kMagic);
    put_varint(v, h.name.size()); v.insert(v.end(), h.name.begin(), h.name.end());
    put_varint(v, h.total); v.push_back((u8)h.tbMax);
    if (h.audio.on()) { v.push_back(2); put_varint(v, h.audio.dataOff); put_varint(v, h.audio.dataLen); v.push_back((u8)h.audio.channels); v.push_back((u8)h.audio.width); }
    else if (h.stride) { v.push_back(1); put_varint(v, (u64)h.stride); v.push_back((u8)h.bpp); }
    else if (h.dedup) {
        v.push_back(3); put_varint(v, h.matches.size()); for (int i = 0; i < 4; i++) v.push_back((u8)(h.fileCrc >> (8 * i)));
        for (const Match& m : h.matches) { put_varint(v, m.gap); put_varint(v, m.len); put_varint(v, m.dist); }
    } else v.push_back(0);
    return v;
}
inline bool read_header(FILE* f, Header& h) {
    u64 used = 0, n = 0;
    if (std::fgetc(f) != kMagic) return false;
    used = 1;
    if (!get_varint(f, n, used) || n == 0 || n > kMaxName) return false;
    h.name.resize((size_t)n); if (std::fread(&h.name[0], 1, (size_t)n, f) != (size_t)n) return false; used += n;
    if (!get_varint(f, h.total, used)) return false;
    int tb = std::fgetc(f); if (tb < 16 || tb > 22) return false; h.tbMax = tb; used++;
    int kind = std::fgetc(f); used++;
    if (kind == 1) {
        u64 st = 0; if (!get_varint(f, st, used) || st == 0 || st > 0x7fffffff) return false; h.stride = (int)st;
        int b = std::fgetc(f); if (b < 1 || b > 8) return false; h.bpp = b; used++;
    } else if (kind == 2) {
        u64 off = 0, len = 0; if (!get_varint(f, off, used) || !get_varint(f, len, used)) return false;
        int ch = std::fgetc(f), w = std::fgetc(f); used += 2;
        if (ch < 1 || ch > 8 || w < 1 || w > 3 || off > h.total || len > h.total - off) return false;
        h.audio.dataOff = off; h.audio.dataLen = len; h.audio.channels = ch; h.audio.width = w;
    } else if (kind == 3) {
        u64 cnt = 0; if (!get_varint(f, cnt, used) || cnt > h.total / 16 + 1) return false;
        u8 c4[4]; if (std::fread(c4, 1, 4, f) != 4) return false; used += 4;
        h.fileCrc = (u32)c4[0] | ((u32)c4[1] << 8) | ((u32)c4[2] << 16) | ((u32)c4[3] << 24);
        h.matches.reserve((size_t)cnt); u64 cursor = 0, matched = 0;
        for (u64 i = 0; i < cnt; i++) {
            Match m; if (!get_varint(f, m.gap, used) || !get_varint(f, m.len, used) || !get_varint(f, m.dist, used)) return false;
            if (m.len == 0 || m.dist == 0 || m.gap > h.total || m.len > h.total) return false;
            cursor += m.gap; if (cursor > h.total || m.dist > cursor) return false;
            cursor += m.len; if (cursor > h.total) return false;
            matched += m.len; h.matches.push_back(m);
        }
        h.dedup = true; h.litTotal = h.total - matched;
    } else if (kind != 0) return false;
    h.bytes = used; return true;
}
inline void detect_geometry(const u8* b, size_t n, int& stride, int& bpp) {      // uncompressed BMP: 8/24/32 bit
    stride = bpp = 0;
    if (n < 30 || b[0] != 'B' || b[1] != 'M') return;
    u32 w = (u32)b[18] | ((u32)b[19] << 8) | ((u32)b[20] << 16); int bits = b[28];
    if ((bits == 8 || bits == 24 || bits == 32) && b[29] == 0 && w > 0 && w < 100000) { bpp = bits / 8; stride = (int)((((u64)w * (u64)bits + 31) / 32) * 4); }
}
// PCM WAV (RIFF/WAVE, 8/16/24-bit, up to 8 channels): finds the "data" chunk
inline bool detect_wav(FILE* f, u64 fileSize, Audio& a) {
    u8 h[12]; if (seek64(f, 0) != 0 || std::fread(h, 1, 12, f) != 12 || std::memcmp(h, "RIFF", 4) || std::memcmp(h + 8, "WAVE", 4)) return false;
    u64 pos = 12; int channels = 0, bits = 0, blockAlign = 0; bool pcm = false;
    for (int guard = 0; guard < 64 && pos + 8 <= fileSize; guard++) {
        u8 c[8]; if (seek64(f, pos) != 0 || std::fread(c, 1, 8, f) != 8) return false;
        u64 size = (u64)c[4] | ((u64)c[5] << 8) | ((u64)c[6] << 16) | ((u64)c[7] << 24);
        if (!std::memcmp(c, "fmt ", 4) && size >= 16) {
            u8 b[40]; size_t want = size >= 40 ? 40 : 16; if (std::fread(b, 1, want, f) != want) return false;
            int tag = b[0] | (b[1] << 8); channels = b[2] | (b[3] << 8); blockAlign = b[12] | (b[13] << 8); bits = b[14] | (b[15] << 8);
            if (tag == 0xFFFE && want == 40) tag = b[24] | (b[25] << 8);                 // WAVE_FORMAT_EXTENSIBLE sub-format
            pcm = (tag == 1);
        } else if (!std::memcmp(c, "data", 4)) {
            if (!pcm || channels < 1 || channels > 8 || (bits != 8 && bits != 16 && bits != 24) || blockAlign != channels * bits / 8) return false;
            u64 off = pos + 8, avail = fileSize > off ? fileSize - off : 0;
            a.dataOff = off; a.dataLen = (size == 0 || size > avail) ? avail : size; a.channels = channels; a.width = bits / 8;
            return a.dataLen >= (u64)a.frame();
        }
        pos += 8 + size + (size & 1);
    }
    return false;
}
// ------------------------------------------------------------------ long-distance duplicate finder
// Rolling hash over a 32-byte window; content-defined anchors (1 in 2^k positions) are remembered in a hash table.
// A hit is verified byte by byte, then extended backwards and forwards. The table is bounded (256 MB), so any
// file size works; the file is read in 16 MB steps and verified through two small block caches.
class FileCache {
public:
    FileCache(const fs::path& p, u64 size) : size_(size), blk_(kBlk) { ok_ = f_.open(p, "rb"); }
    bool ok() const { return ok_; }
    const u8* get(u64 pos, size_t& avail) {
        if (pos >= size_) { avail = 0; return nullptr; }
        if (pos < off_ || pos >= off_ + len_) {
            off_ = pos & ~(u64)(kBlk - 1);
            if (seek64(f_.f, off_) != 0) { len_ = 0; avail = 0; return nullptr; }
            len_ = std::fread(blk_.data(), 1, kBlk, f_.f);
            if (pos >= off_ + len_) { avail = 0; return nullptr; }
        }
        avail = (size_t)(off_ + len_ - pos); return blk_.data() + (pos - off_);
    }
    int at(u64 pos) { size_t a; const u8* p = get(pos, a); return p ? (int)*p : -1; }
private:
    static constexpr size_t kBlk = (size_t)1 << 22;
    File f_; bool ok_ = false; u64 size_, off_ = ~(u64)0; size_t len_ = 0; std::vector<u8> blk_;
};
inline u64 common_forward(FileCache& a, u64 pa, FileCache& b, u64 pb, u64 maxLen) {
    u64 total = 0;
    while (total < maxLen) {
        size_t aa, ab; const u8* x = a.get(pa + total, aa); const u8* y = b.get(pb + total, ab);
        if (!x || !y) break;
        size_t m = (size_t)std::min<u64>(std::min<u64>(aa, ab), maxLen - total), k = 0;
        while (k < m && x[k] == y[k]) k++;
        total += k; if (k < m) break;
    }
    return total;
}
// returns false on cancel/read error. cancelled is set when prog returned false.
inline bool find_duplicates(const fs::path& src, u64 n, u64 tableBudget, const std::function<bool(double)>& prog,
                            std::vector<Match>& out, u64& matched, bool& cancelled) {
    cancelled = false; out.clear(); matched = 0;
    const int k = std::max(7, ceil_log2(n) - 24);
    const u64 minm = (u64)4 << k;
    u64 anchors = (n >> k) + 1, cap = (u64)1 << 16;
    while (cap < anchors + anchors / 4 && cap < ((u64)1 << 26)) cap <<= 1;
    while (cap * 12 > tableBudget && cap > ((u64)1 << 16)) cap >>= 1;
    std::vector<u64> tpos((size_t)cap, 0); std::vector<u32> tchk((size_t)cap, 0);
    FileCache cs(src, n), cd(src, n); File in;
    if (!cs.ok() || !cd.ok() || !in.open(src, "rb")) return false;
    const size_t kBuf = (size_t)16 << 20; std::vector<u8> buf(kBuf);
    const u64 B = 0x100000001B3ull; u64 Bpow = 1; for (int i = 0; i < 32; i++) Bpow *= B;
    u64 pos = 0, litStart = 0, bufStart = 0, bufEnd = 0, h = 0; int fill = 0; u8 win[32]; unsigned wi = 0;
    const int shift = 64 - k;
    while (pos < n) {
        if (pos < bufStart || pos >= bufEnd) {
            if (prog && !prog((double)pos / (double)n)) { cancelled = true; return false; }
            if (seek64(in.f, pos) != 0) return false;
            size_t got = std::fread(buf.data(), 1, (size_t)std::min<u64>(kBuf, n - pos), in.f); if (got == 0) return false;
            bufStart = pos; bufEnd = pos + got;
        }
        size_t i = (size_t)(pos - bufStart), end = (size_t)(bufEnd - bufStart); bool jumped = false;
        for (; i < end; i++) {
            u8 c = buf[i];
            if (fill < 32) { h = h * B + c; win[wi] = c; wi = (wi + 1) & 31; if (++fill < 32) continue; }
            else { u8 o = win[wi]; win[wi] = c; wi = (wi + 1) & 31; h = h * B + c - (u64)o * Bpow; }
            u64 mix = h * 0x9E3779B97F4A7C15ull;
            if ((mix >> shift) != 0) continue;
            u64 p = bufStart + i + 1;
            size_t slot = (size_t)((mix >> 8) & (cap - 1)); u32 chk = (u32)((h * 0xC2B2AE3D27D4EB4Full) >> 32) | 1u;
            u64 q = tpos[slot];
            if (q && tchk[slot] == chk) {
                u64 dist = p - q, maxb = std::min<u64>(std::min<u64>(p - litStart, q), (u64)1 << 20), bk = 0;
                while (bk < maxb && cd.at(p - 1 - bk) == cs.at(q - 1 - bk)) bk++;
                u64 fw = common_forward(cd, p, cs, q, n - p);
                u64 len = bk + fw, start = p - bk;                                     // len > dist = repeating run / pattern
                if (len >= minm && start + len >= p) {
                    out.push_back(Match{start - litStart, len, dist}); matched += len; litStart = start + len;
                    pos = litStart; fill = 0; h = 0; wi = 0; jumped = true; break;
                }
            }
            tpos[slot] = p; tchk[slot] = chk;
        }
        if (!jumped) pos = bufEnd;
    }
    return true;
}
struct CrcJob { fs::path path; u32 crc = 0; bool ok = true; };
inline void crc_file(CrcJob* j) {
    File f; if (!f.open(j->path, "rb")) { j->ok = false; return; }
    std::vector<u8> b((size_t)4 << 20); size_t g;
    while ((g = std::fread(b.data(), 1, b.size(), f.f)) > 0) j->crc = crc32_update(j->crc, b.data(), g);
}
// literal stream = the file without the matched ranges
struct LitRun { u64 off, len, cum; };
inline std::vector<LitRun> make_runs(const std::vector<Match>& m, u64 n) {
    std::vector<LitRun> r; u64 cursor = 0, cum = 0;
    for (const Match& x : m) { if (x.gap) { r.push_back(LitRun{cursor, x.gap, cum}); cum += x.gap; } cursor += x.gap + x.len; }
    if (cursor < n) r.push_back(LitRun{cursor, n - cursor, cum});
    return r;
}
inline bool read_literals(FILE* f, const std::vector<LitRun>& runs, u64 vstart, size_t L, u8* dst) {
    if (runs.empty()) return L == 0;
    size_t lo = 0, hi = runs.size();
    while (lo + 1 < hi) { size_t mid = (lo + hi) / 2; if (runs[mid].cum <= vstart) lo = mid; else hi = mid; }
    u64 v = vstart; size_t need = L;
    for (size_t ri = lo; need && ri < runs.size(); ri++) {
        const LitRun& r = runs[ri]; u64 skip = v - r.cum, take = std::min<u64>(r.len - skip, need);
        if (seek64(f, r.off + skip) != 0 || std::fread(dst, 1, (size_t)take, f) != (size_t)take) return false;
        dst += take; v += take; need -= (size_t)take;
    }
    return need == 0;
}
// Output side: writes literal runs and executes the copy records in order. Matches within the last 64 MB are served
// from an in-memory window; older ones are read back from the output file.
class OutWriter {
public:
    OutWriter(FILE* out, const fs::path& tmp, const std::vector<Match>* m, Counters& cn) : out_(out), tmp_(tmp), m_(m), cn_(cn) {
        if (m_) { ring_.resize(kRing); chunk_.resize(kChunk); gapLeft_ = m_->empty() ? ~(u64)0 : (*m_)[0].gap; }
    }
    void append(const u8* p, size_t L) {
        if (!m_) { write(p, L); return; }
        size_t i = 0;
        for (;;) {
            applyReady();
            if (i >= L) break;
            size_t take = (size_t)std::min<u64>(gapLeft_, (u64)(L - i));
            write(p + i, take); i += take; if (gapLeft_ != ~(u64)0) gapLeft_ -= take;
        }
    }
    void finish() { if (m_) applyReady(); }
    u64 pos() const { return pos_; }
    u32 crc() const { return crc_; }
private:
    static constexpr size_t kRing = (size_t)64 << 20, kChunk = (size_t)4 << 20;
    void applyReady() {
        while (mi_ < m_->size() && gapLeft_ == 0) { copyMatch((*m_)[mi_]); mi_++; gapLeft_ = mi_ < m_->size() ? (*m_)[mi_].gap : ~(u64)0; }
    }
    void write(const u8* p, size_t L) {
        if (!L) return;
        if (std::fwrite(p, 1, L, out_) != L) throw Failure{Status::DiskFull, "write failed (disk full?)"};
        if (m_) {
            crc_ = crc32_update(crc_, p, L);
            size_t at = (size_t)(pos_ & (kRing - 1)), first = std::min(L, kRing - at);
            std::memcpy(ring_.data() + at, p, first); if (first < L) std::memcpy(ring_.data(), p + first, L - first);
        }
        pos_ += L;
    }
    void readBack(u64 src, size_t c, u64 dist, u8* dst) {                 // c bytes starting at output offset src
        if (dist <= kRing) {
            size_t at = (size_t)(src & (kRing - 1)), first = std::min(c, kRing - at);
            std::memcpy(dst, ring_.data() + at, first); if (first < c) std::memcpy(dst + first, ring_.data(), c - first);
        } else {
            if (std::fflush(out_) != 0) throw Failure{Status::DiskFull, "write failed (disk full?)"};
            if (!rd_.f && !rd_.open(tmp_, "rb")) throw Failure{Status::IoError, "cannot re-read the output file"};
            if (seek64(rd_.f, src) != 0 || std::fread(dst, 1, c, rd_.f) != c) throw Failure{Status::IoError, "cannot re-read the output file"};
        }
    }
    void copyMatch(const Match& m) {
        if (m.dist > pos_) throw Failure{Status::Corrupt, "file is damaged (bad copy record)"};
        u64 left = m.len;
        while (left) {
            size_t c = (size_t)std::min<u64>(left, kChunk);
            if (m.dist >= c) readBack(pos_ - m.dist, c, m.dist, chunk_.data());
            else {                                                       // overlapping copy: repeat the last `dist` bytes
                size_t d = (size_t)m.dist; readBack(pos_ - m.dist, d, m.dist, chunk_.data());
                for (size_t i = d; i < c; i++) chunk_[i] = chunk_[i - d];
            }
            write(chunk_.data(), c); cn_.out.fetch_add(c, std::memory_order_relaxed); left -= c;
        }
    }
    FILE* out_; fs::path tmp_; const std::vector<Match>* m_; Counters& cn_; File rd_;
    std::vector<u8> ring_, chunk_; u64 pos_ = 0, gapLeft_ = 0; size_t mi_ = 0; u32 crc_ = 0;
};

inline Hint make_hint(const Header& h, u64 segStart, size_t L, int audioCode) {
    Hint t; t.stride = h.stride; t.bpp = h.bpp;
    if (h.audio.on() && audioCode > 0) {
        size_t ts, te; audio_region(h.audio, segStart, L, ts, te);
        if (te > ts) { t.ats = ts; t.ate = te; t.channels = h.audio.channels; t.width = h.audio.width; }
    }
    return t;
}
inline void remove_quiet(const fs::path& p) { std::error_code ec; fs::remove(p, ec); }
inline Result fail(Status s, const std::string& m) { Result r; r.status = s; r.message = m; return r; }

// shared state of one parallel run
struct Shared {
    sys::Mutex m; sys::CondVar cv;
    u64 nextWrite = 0; unsigned alive = 0; bool failed = false; Status st = Status::Ok; std::string msg;
    std::atomic<u64> nextSeg{0}; Counters cn; bool userCancel = false;
    void error(Status s, const std::string& text) { sys::Lock l(m); if (!failed) { failed = true; st = s; msg = text; } cn.cancel = true; cv.notify_all(); }
};
// Memory per worker: ~195 MB with 22-bit tables, ~115 MB with 21-bit tables.
inline u64 per_thread_bytes(int tbMax) { return (u64)(tbMax >= 22 ? 200 : 120) << 20; }
inline unsigned pick_threads(const Options& o, u64 segments, int tbMax) {
    unsigned t = o.threads ? o.threads : std::min(sys::hardware_threads(), 16u);
    u64 budget = o.memoryBudget ? o.memoryBudget : ((u64)2 << 30);
    u64 cap = budget / per_thread_bytes(tbMax); t = (unsigned)std::min<u64>(t, std::max<u64>(1, cap));
    if (t > segments) t = (unsigned)std::max<u64>(1, segments);
    return std::max(1u, t);
}
// compression: largest tables that fit the memory budget with the wanted number of threads
inline void plan(const Options& o, u64 segments, unsigned& threads, int& tbMax) {
    unsigned want = o.threads ? o.threads : std::min(sys::hardware_threads(), 16u);
    if (want > segments) want = (unsigned)std::max<u64>(1, segments);
    u64 budget = o.memoryBudget ? o.memoryBudget : ((u64)2 << 30);
    if ((u64)want * per_thread_bytes(22) <= budget) { threads = want; tbMax = 22; return; }
    tbMax = 21; threads = (unsigned)std::min<u64>(want, std::max<u64>(1, budget / per_thread_bytes(21)));
}
// runs `worker` on n threads and polls progress on the calling thread until all are done
inline void run_workers(Shared& sh, unsigned n, u64 total, const std::function<void()>& worker, const ProgressFn& progress) {
    std::vector<std::unique_ptr<sys::Thread>> th;
    { sys::Lock l(sh.m); sh.alive = n; }
    for (unsigned i = 0; i < n; i++) {
        th.emplace_back(new sys::Thread());
        bool ok = th.back()->start([&sh, &worker] {
            try { worker(); } catch (const Cancelled&) {} catch (const Failure& f) { sh.error(f.status, f.msg); }
            catch (const std::bad_alloc&) { sh.error(Status::OutOfMemory, "not enough memory"); }
            catch (const std::exception& e) { sh.error(Status::IoError, e.what()); }
            sys::Lock l(sh.m); sh.alive--; sh.cv.notify_all();
        });
        if (!ok) { sys::Lock l(sh.m); sh.alive--; if (i == 0) { sh.failed = true; sh.st = Status::OutOfMemory; sh.msg = "cannot start worker threads"; } }
    }
    for (;;) {
        { sys::Lock l(sh.m); if (sh.alive == 0) break; sh.cv.wait_ms(sh.m, 100); }
        double f = total ? (double)sh.cn.done.load() / (double)total : 1.0;
        if (progress && !progress(f > 1.0 ? 1.0 : f, sh.cn.out.load())) { sys::Lock l(sh.m); sh.userCancel = true; sh.cn.cancel = true; sh.cv.notify_all(); }
    }
    for (auto& t : th) t->join();
}

}  // namespace detail

namespace detail {
// Encoder-side choice for one segment: 0 = plain bytes, 1..3 = audio presets 0..2. Trial-codes a sample of the
// PCM region each way (about 128 KB each) and keeps the smallest. Decoding never needs to repeat this.
inline int choose_audio_code(const Header& h, const u8* seg, size_t L, u64 segStart, int tbMax) {
    size_t ts, te; audio_region(h.audio, segStart, L, ts, te);
    if (te <= ts) return 0;
    size_t frame = (size_t)h.audio.frame(), span = te - ts, want = std::min<size_t>(span, (size_t)128 << 10);
    want -= want % frame; if (want < frame * 256) return 0;
    size_t from = ts + ((span - want) / 2 / frame) * frame;           // sample from the middle of the region
    std::vector<u8> work(seg + from, seg + from + want), out; Counters dummy;
    Hint none; encode_segment(work.data(), want, tbMax, none, out, dummy); const size_t plain = out.size();
    size_t best = (size_t)-1; int code = 0;
    for (int p = 0; p < 3; p++) {
        std::memcpy(work.data(), seg + from, want);
        AudioCodec(h.audio.channels, h.audio.width, p).forward(work.data(), want / frame);
        Hint hint; hint.ats = 0; hint.ate = want; hint.channels = h.audio.channels; hint.width = h.audio.width;
        encode_segment(work.data(), want, tbMax, hint, out, dummy);
        if (out.size() < best) { best = out.size(); code = p + 1; }
    }
    if (best + best / 64 >= plain) code = 0;          // plain bytes unless audio mode is clearly (1.5%) better
    return code;
}

// Headerless data: looks for (a) 16-bit PCM audio and (b) a record / image-row size, using cheap statistics on a 2 MB
// sample first and trial-coding a 512 KB slice only for promising candidates. Writes the result into h (audio or stride+bpp).
inline void detect_structure(const fs::path& src, u64 n, Header& h) {
    if (n < ((u64)512 << 10)) return;
    const size_t S = (size_t)std::min<u64>(n, (u64)2 << 20);
    std::vector<u8> smp(S); u64 from = ((n - S) / 2) & ~(u64)7;
    { File f; if (!f.open(src, "rb") || seek64(f.f, from) != 0 || std::fread(smp.data(), 1, S, f.f) != S) return; }
    const int kTb = 22; const size_t T = std::min<size_t>(S, (size_t)256 << 10), tOff = (S - T) / 2 & ~(size_t)7;
    auto trial = [&](const std::vector<u8>& d, const Hint& hint) { std::vector<u8> o; Counters dummy; encode_segment(d.data(), d.size(), kTb, hint, o, dummy); return o.size(); };
    std::vector<u8> slice(smp.begin() + tOff, smp.begin() + tOff + T);
    size_t plain = 0; bool havePlain = false;
    auto plainSize = [&]() { if (!havePlain) { plain = trial(slice, Hint()); havePlain = true; } return plain; };
    size_t bestSize = (size_t)-1; Audio bestAudio; int bestStride = 0, bestBpp = 0;

    // (a) headerless 16-bit PCM, mono or stereo: samples must be much smoother than they are large
    for (int ch = 1; ch <= 2; ch++) {
        size_t fb = (size_t)(2 * ch), frames = std::min<size_t>(S / fb, 40000) - 1; double d = 0, a = 0;
        for (size_t t = 1; t <= frames; t++) {
            int cur = (int)(i16)(smp[t * fb] | (smp[t * fb + 1] << 8)), prv = (int)(i16)(smp[(t - 1) * fb] | (smp[(t - 1) * fb + 1] << 8));
            d += std::abs(cur - prv); a += std::abs(cur);
        }
        if (a > 0 && d / a < 0.8) {
            std::vector<u8> w = slice; size_t frame = fb, usable = (T / frame) * frame; w.resize(usable);
            AudioCodec(ch, 2, 1).forward(w.data(), usable / frame);
            Hint hint; hint.ats = 0; hint.ate = usable; hint.channels = ch; hint.width = 2;
            size_t sz = trial(w, hint), ref = plainSize();
            if (sz + sz / 32 < ref && sz < bestSize) { bestSize = sz; bestAudio = Audio(); bestAudio.dataOff = 0; bestAudio.dataLen = n; bestAudio.channels = ch; bestAudio.width = 2; bestStride = 0; }
        }
    }
    // (b) record length / image row length: byte-difference at lag L is much smaller than for unrelated bytes
    const size_t maxLag = std::min<size_t>(S / 4, 49152), minLag = 8, np = 3000;
    std::vector<double> sad(maxLag + 1, 0.0);
    size_t first = maxLag, span = S - first, stepP = std::max<size_t>(1, span / np);
    std::vector<size_t> pos; for (size_t i = first; i < S; i += stepP) pos.push_back(i);
    for (size_t L = 1; L <= maxLag; L++) { u64 acc = 0; for (size_t i : pos) { int dv = (int)smp[i] - (int)smp[i - L]; acc += (u64)(dv < 0 ? -dv : dv); } sad[L] = (double)acc / (double)pos.size(); }
    std::vector<double> srt(sad.begin() + 1, sad.end()); std::nth_element(srt.begin(), srt.begin() + srt.size() / 2, srt.end());
    double median = srt[srt.size() / 2];
    std::vector<size_t> cand;
    {   // lags that are clear local dips (record / row length), best prominence first
        std::vector<std::pair<double, size_t>> order;
        for (size_t L = minLag + 3; L + 3 <= maxLag; L++) {
            if (!(sad[L] < 0.8 * median)) continue;
            double nb = (sad[L - 3] + sad[L - 2] + sad[L + 2] + sad[L + 3]) / 4.0, prom = (nb - sad[L]) / (nb > 0 ? nb : 1.0);
            if (prom >= 0.03 && sad[L] <= sad[L - 1] && sad[L] <= sad[L + 1]) order.push_back({prom, L});
        }
        std::sort(order.begin(), order.end(), [](const std::pair<double, size_t>& x, const std::pair<double, size_t>& y) { return x.first > y.first; });
        for (auto& pr : order) { size_t L = pr.second; bool tooClose = false; for (size_t c : cand) if ((L > c ? L - c : c - L) <= 4) tooClose = true; if (!tooClose) cand.push_back(L); if (cand.size() == 2) break; }
    }
    if (!cand.empty()) {
        int bppA = 1; double bs = sad[1]; for (int k = 2; k <= 4; k++) if (sad[k] < bs) { bs = sad[k]; bppA = k; }
        std::vector<int> bpps; bpps.push_back(bppA); if (bppA != 1) bpps.push_back(1);
        for (size_t L : cand) for (int bp : bpps) {
            Hint hint; hint.stride = (int)L; hint.bpp = bp;
            size_t sz = trial(slice, hint), ref = plainSize();
            if (sz + sz / 50 < ref && sz < bestSize) { bestSize = sz; bestStride = (int)L; bestBpp = bp; bestAudio = Audio(); }
        }
    }
    if (bestSize != (size_t)-1) { if (bestAudio.on()) h.audio = bestAudio; else { h.stride = bestStride; h.bpp = bestBpp; } }
}

}  // namespace detail

// ------------------------------------------------------------------ public functions
inline Result restore_file(const fs::path& src, const Options& opt, const ProgressFn& progress);

// Compress src into <outDir>/<stem>.3p. The original name + extension are stored in the metadata.
inline Result compress_file(const fs::path& src, const Options& opt, const ProgressFn& progress) {
    using namespace detail;
    fs::path tmp;
    try {
        std::error_code ec;
        u64 n = (u64)fs::file_size(src, ec); if (ec) return fail(Status::IoError, "cannot read file size: " + ec.message());
        fs::file_time_type sourceTime{};
        if (opt.replaceSource) { sourceTime = fs::last_write_time(src, ec); if (ec) return fail(Status::IoError, "cannot inspect source file timestamp: " + ec.message()); }
        Header h; h.name = to_utf8(src.filename()); h.total = n;
        if (h.name.empty() || h.name.size() > kMaxName) return fail(Status::IoError, "file name is empty or too long");
        { std::string e = to_utf8(src.extension()); for (char& c : e) c = (char)std::tolower((unsigned char)c); if (e == extension()) return fail(Status::BadFormat, "already a .3p file"); }
        { File f; if (!f.open(src, "rb")) return fail(Status::IoError, "cannot open the source file");
          if (!detect_wav(f.f, n, h.audio)) { h.audio = Audio(); seek64(f.f, 0); u8 head[64]; size_t got = std::fread(head, 1, sizeof head, f.f); detect_geometry(head, got, h.stride, h.bpp); } }

        // long-distance duplicates (not for WAV / BMP: their audio / pixel modelling relies on the exact byte layout)
        u64 streamLen = n; std::vector<LitRun> runs; double base = 0.0;
        if (!h.audio.on() && !h.stride && opt.dedup && n >= ((u64)2 << 20)) {
            CrcJob job; job.path = src; sys::Thread crcThread; crcThread.start([&job] { crc_file(&job); });
            std::vector<Match> found; u64 matched = 0; bool cancelled = false;
            bool ok = find_duplicates(src, n, (u64)256 << 20, [&](double f) { return !progress || progress(0.03 * f, 0); }, found, matched, cancelled);
            crcThread.join();
            if (!ok) return fail(cancelled ? Status::Cancelled : Status::IoError, cancelled ? "cancelled" : "could not read the source file");
            base = 0.03;
            if (job.ok && matched >= std::max<u64>(n / 100, (u64)65536)) {
                h.dedup = true; h.matches = std::move(found); h.fileCrc = job.crc; streamLen = n - matched; runs = make_runs(h.matches, n);
            }
        }
        if (!h.dedup && !h.audio.on() && !h.stride && opt.detect) detect_structure(src, n, h);
        u64 nseg = (streamLen + kSegment - 1) / kSegment;
        unsigned threads = 1;
        plan(opt, nseg, threads, h.tbMax);

        fs::path dir = opt.replaceSource ? src.parent_path() : (opt.outDir.empty() ? src.parent_path() : opt.outDir); if (dir.empty()) dir = ".";
        std::string outputBase = opt.replaceSource ? to_utf8(src.filename()) : to_utf8(src.stem());
        fs::path finalPath = unique_path(dir, outputBase + extension());
        tmp = finalPath; tmp += ".tmp";
        File out; if (!out.open(tmp, "wb")) return fail(Status::IoError, "cannot create the output file (folder not writable?)");
        std::vector<u8> hv = make_header(h);
        if (std::fwrite(hv.data(), 1, hv.size(), out.f) != hv.size()) return fail(Status::IoError, "write failed");

        Shared sh; u64 written = hv.size(); sh.cn.out = hv.size();
        auto worker = [&]() {
            File f; if (!f.open(src, "rb")) throw Failure{Status::IoError, "cannot open the source file"};
            std::vector<u8> seg(kSegment), payload, check;
            for (;;) {
                u64 idx = sh.nextSeg.fetch_add(1);
                if (idx >= nseg || sh.cn.cancel.load()) return;
                size_t L = (size_t)std::min<u64>(kSegment, streamLen - idx * kSegment);
                if (h.dedup ? !read_literals(f.f, runs, idx * kSegment, L, seg.data()) : (seek64(f.f, idx * kSegment) != 0 || std::fread(seg.data(), 1, L, f.f) != L)) throw Failure{Status::IoError, "could not read the source file (changed while reading?)"};
                u32 crc = crc32(seg.data(), L);
                int code = h.audio.on() ? choose_audio_code(h, seg.data(), L, idx * kSegment, h.tbMax) : 0;
                Hint hint = make_hint(h, idx * kSegment, L, code);
                if (hint.ate > hint.ats) AudioCodec(h.audio.channels, h.audio.width, code - 1).forward(seg.data() + hint.ats, (size_t)((hint.ate - hint.ats) / (u64)h.audio.frame()));
                encode_segment(seg.data(), L, h.tbMax, hint, payload, sh.cn);
                bool modeled = payload.size() < L;
                if (modeled && (opt.verify || opt.replaceSource)) {
                    check.resize(L); decode_segment(payload.data(), payload.size(), check.data(), L, h.tbMax, hint, nullptr);
                    if (hint.ate > hint.ats) AudioCodec(h.audio.channels, h.audio.width, code - 1).inverse(check.data() + hint.ats, (size_t)((hint.ate - hint.ats) / (u64)h.audio.frame()));
                    if (crc32(check.data(), L) != crc) throw Failure{Status::Corrupt, "verification failed: decoded data differs from the original"};
                }
                if (!modeled) {
                    if (hint.ate > hint.ats) { if (seek64(f.f, idx * kSegment) != 0 || std::fread(seg.data(), 1, L, f.f) != L) throw Failure{Status::IoError, "could not read the source file"}; }
                    payload.assign(seg.begin(), seg.begin() + L);
                }
                std::vector<u8> fh; put_varint(fh, ((u64)payload.size() << 3) | (u64)((modeled ? code : 0) << 1) | (modeled ? 1u : 0u));
                for (int i = 0; i < 4; i++) fh.push_back((u8)(crc >> (8 * i)));
                sys::Lock l(sh.m);
                while (sh.nextWrite != idx && !sh.cn.cancel.load()) sh.cv.wait(sh.m);
                if (sh.cn.cancel.load()) return;
                if (std::fwrite(fh.data(), 1, fh.size(), out.f) != fh.size() || std::fwrite(payload.data(), 1, payload.size(), out.f) != payload.size()) {
                    sh.failed = true; sh.st = Status::DiskFull; sh.msg = "write failed (disk full?)"; sh.cn.cancel = true; sh.cv.notify_all(); return; }
                written += fh.size() + payload.size(); sh.nextWrite++; sh.cv.notify_all();
            }
        };
        ProgressFn mapped = progress ? ProgressFn([&](double f, u64 o) { return progress(base + (1.0 - base) * f, o); }) : ProgressFn();
        run_workers(sh, threads, streamLen, worker, mapped);
        if (sh.failed) { out.close(); remove_quiet(tmp); return fail(sh.st, sh.msg); }
        if (sh.userCancel || sh.nextWrite != nseg) { out.close(); remove_quiet(tmp); return fail(Status::Cancelled, "cancelled"); }
        if (std::fflush(out.f) != 0) { out.close(); remove_quiet(tmp); return fail(Status::DiskFull, "write failed (disk full?)"); }
        out.close();
        fs::rename(tmp, finalPath, ec);
        if (ec) { remove_quiet(tmp); return fail(Status::IoError, "cannot finalize the output file: " + ec.message()); }
        if (opt.replaceSource) {
            if (written >= n) { remove_quiet(finalPath); return fail(Status::NotSmaller, "compressed file is not smaller; original was kept"); }

            // Fully restore into a temporary sibling directory and compare byte-for-byte
            // before deleting the user's source. Per-segment encoding checks alone do not
            // validate duplicate-copy records as a complete archive.
            fs::path verifyDir; bool madeVerifyDir = false;
            for (unsigned i = 0; i < 10000; i++) {
                verifyDir = dir / (".3p-verify-" + std::to_string(i));
                std::error_code makeEc;
                if (fs::create_directory(verifyDir, makeEc)) { madeVerifyDir = true; break; }
                if (makeEc && makeEc != std::errc::file_exists) { remove_quiet(finalPath); return fail(Status::IoError, "could not create a verification folder: " + makeEc.message()); }
            }
            if (!madeVerifyDir) { remove_quiet(finalPath); return fail(Status::IoError, "could not create a verification folder"); }
            Options verifyOpt; verifyOpt.memoryBudget = opt.memoryBudget; verifyOpt.threads = opt.threads; verifyOpt.outDir = verifyDir;
            Result verified = restore_file(finalPath, verifyOpt, ProgressFn());
            bool identical = verified.status == Status::Ok && verified.outSize == n;
            if (identical) {
                File originalCheck, restoredCheck;
                if (!originalCheck.open(src, "rb") || !restoredCheck.open(verified.outPath, "rb")) identical = false;
                else {
                    std::vector<u8> originalBytes((size_t)1 << 20), restoredBytes((size_t)1 << 20);
                    for (;;) {
                        size_t originalRead = std::fread(originalBytes.data(), 1, originalBytes.size(), originalCheck.f);
                        size_t restoredRead = std::fread(restoredBytes.data(), 1, restoredBytes.size(), restoredCheck.f);
                        if (originalRead != restoredRead || (originalRead && std::memcmp(originalBytes.data(), restoredBytes.data(), originalRead) != 0)) { identical = false; break; }
                        if (originalRead == 0) break;
                    }
                    if (std::ferror(originalCheck.f) || std::ferror(restoredCheck.f)) identical = false;
                }
            }
            if (verified.status == Status::Ok) remove_quiet(verified.outPath);
            std::error_code verifyCleanupEc; fs::remove(verifyDir, verifyCleanupEc);
            if (!identical) {
                remove_quiet(finalPath);
                if (verified.status != Status::Ok) return fail(verified.status, "replacement verification failed; original was kept: " + verified.message);
                return fail(Status::Corrupt, "replacement verification failed; original was kept");
            }
            if (verifyCleanupEc) {
                Result kept = fail(Status::IoError, "could not remove the verification file; original kept, archive saved at " + to_utf8(finalPath));
                kept.outPath = finalPath; return kept;
            }

            std::error_code sizeEc, timeEc;
            u64 currentSize = (u64)fs::file_size(src, sizeEc);
            auto currentTime = fs::last_write_time(src, timeEc);
            if (sizeEc || timeEc || currentSize != n || currentTime != sourceTime) {
                Result changed = fail(Status::IoError, "source changed during compression; original kept, archive saved at " + to_utf8(finalPath));
                changed.outPath = finalPath; return changed;
            }
            std::error_code removeEc;
            if (!fs::remove(src, removeEc) || removeEc) {
                Result kept = fail(Status::IoError, "could not remove the original; archive saved at " + to_utf8(finalPath));
                kept.outPath = finalPath; return kept;
            }
        }
        Result r; r.inSize = n; r.outSize = written; r.outPath = finalPath; r.storedName = h.name;
        if (progress) progress(1.0, written);
        return r;
    } catch (const std::bad_alloc&) { if (!tmp.empty()) remove_quiet(tmp); return fail(Status::OutOfMemory, "not enough memory");
    } catch (const std::exception& e) { if (!tmp.empty()) remove_quiet(tmp); return fail(Status::IoError, e.what()); }
}

// Restore a .3p file under its original name and extension (read from the metadata).
inline Result restore_file(const fs::path& src, const Options& opt, const ProgressFn& progress) {
    using namespace detail;
    fs::path tmp;
    try {
        std::error_code ec;
        u64 fileSize = (u64)fs::file_size(src, ec); if (ec) return fail(Status::IoError, "cannot read file size: " + ec.message());
        Header h;
        { File f; if (!f.open(src, "rb")) return fail(Status::IoError, "cannot open the file"); if (!read_header(f.f, h)) return fail(Status::BadFormat, "not a valid .3p file"); }
        const u64 streamLen = h.dedup ? h.litTotal : h.total;
        u64 nseg = (streamLen + kSegment - 1) / kSegment;
        if ((!h.dedup && h.total > fileSize * 4096 + kSegment) || nseg * 5 > fileSize) return fail(Status::BadFormat, "not a valid .3p file (damaged header)");

        struct Frame { u64 off = 0, plen = 0; u32 crc = 0; bool modeled = false; int code = 0; };
        std::vector<Frame> frames((size_t)nseg);
        { File f; if (!f.open(src, "rb") || seek64(f.f, h.bytes) != 0) return fail(Status::IoError, "cannot open the file");
          u64 pos = h.bytes;
          for (u64 i = 0; i < nseg; i++) {
              u64 v = 0, used = 0; u8 c4[4];
              if (!get_varint(f.f, v, used) || std::fread(c4, 1, 4, f.f) != 4) return fail(Status::Corrupt, "file is truncated or damaged");
              Frame& fr = frames[(size_t)i]; fr.plen = v >> 3; fr.modeled = (v & 1) != 0; fr.code = (int)((v >> 1) & 3);
              fr.crc = (u32)c4[0] | ((u32)c4[1] << 8) | ((u32)c4[2] << 16) | ((u32)c4[3] << 24);
              fr.off = pos + used + 4;
              u64 L = std::min<u64>(kSegment, streamLen - i * kSegment);
              if (fr.plen > L || (!fr.modeled && fr.plen != L) || fr.off + fr.plen > fileSize) return fail(Status::Corrupt, "file is truncated or damaged");
              pos = fr.off + fr.plen; if (seek64(f.f, pos) != 0) return fail(Status::Corrupt, "file is truncated or damaged");
          } }

        std::string name = safe_name(h.name);
        fs::path dir = opt.outDir.empty() ? src.parent_path() : opt.outDir; if (dir.empty()) dir = ".";
        { std::error_code e2; auto sp = fs::space(dir, e2); if (!e2 && sp.available < h.total) return fail(Status::DiskFull, "not enough free disk space for the restored file"); }
        fs::path finalPath = unique_path(dir, name);
        tmp = finalPath; tmp += ".tmp";
        File out; if (!out.open(tmp, "wb")) return fail(Status::IoError, "cannot create the output file (folder not writable?)");

        unsigned threads = pick_threads(opt, nseg, h.tbMax);
        Shared sh;
        OutWriter writer(out.f, tmp, h.dedup ? &h.matches : nullptr, sh.cn);
        auto worker = [&]() {
            File f; if (!f.open(src, "rb")) throw Failure{Status::IoError, "cannot open the file"};
            std::vector<u8> payload, seg;
            for (;;) {
                u64 idx = sh.nextSeg.fetch_add(1);
                if (idx >= nseg || sh.cn.cancel.load()) return;
                const Frame& fr = frames[(size_t)idx];
                size_t L = (size_t)std::min<u64>(kSegment, streamLen - idx * kSegment);
                payload.resize((size_t)fr.plen); seg.resize(L);
                if (seek64(f.f, fr.off) != 0 || std::fread(payload.data(), 1, payload.size(), f.f) != payload.size()) throw Failure{Status::Corrupt, "file is truncated or damaged"};
                Hint hint = make_hint(h, idx * kSegment, L, fr.modeled ? fr.code : 0);
                if (fr.modeled) {
                    decode_segment(payload.data(), payload.size(), seg.data(), L, h.tbMax, hint, &sh.cn);
                    if (hint.ate > hint.ats) AudioCodec(h.audio.channels, h.audio.width, fr.code - 1).inverse(seg.data() + hint.ats, (size_t)((hint.ate - hint.ats) / (u64)h.audio.frame()));
                }
                else { std::memcpy(seg.data(), payload.data(), L); sh.cn.done.fetch_add(L); sh.cn.out.fetch_add(L); }
                if (crc32(seg.data(), L) != fr.crc) throw Failure{Status::Corrupt, "file is damaged: checksum does not match"};
                sys::Lock l(sh.m);
                while (sh.nextWrite != idx && !sh.cn.cancel.load()) sh.cv.wait(sh.m);
                if (sh.cn.cancel.load()) return;
                writer.append(seg.data(), L);
                sh.nextWrite++; sh.cv.notify_all();
            }
        };
        run_workers(sh, threads, streamLen, worker, progress);
        if (sh.failed) { out.close(); remove_quiet(tmp); return fail(sh.st, sh.msg); }
        if (sh.userCancel || sh.nextWrite != nseg) { out.close(); remove_quiet(tmp); return fail(Status::Cancelled, "cancelled"); }
        try { writer.finish(); } catch (const Failure& f) { out.close(); remove_quiet(tmp); return fail(f.status, f.msg); }
        if (writer.pos() != h.total || (h.dedup && writer.crc() != h.fileCrc)) { out.close(); remove_quiet(tmp); return fail(Status::Corrupt, "file is damaged: checksum does not match"); }
        if (std::fflush(out.f) != 0) { out.close(); remove_quiet(tmp); return fail(Status::DiskFull, "write failed (disk full?)"); }
        out.close();
        fs::rename(tmp, finalPath, ec);
        if (ec) { remove_quiet(tmp); return fail(Status::IoError, "cannot finalize the output file: " + ec.message()); }
        Result r; r.inSize = fileSize; r.outSize = h.total; r.outPath = finalPath; r.storedName = h.name;
        if (progress) progress(1.0, h.total);
        return r;
    } catch (const std::bad_alloc&) { if (!tmp.empty()) remove_quiet(tmp); return fail(Status::OutOfMemory, "not enough memory");
    } catch (const std::exception& e) { if (!tmp.empty()) remove_quiet(tmp); return fail(Status::IoError, e.what()); }
}

// Reads only the metadata: stored name and original size (instant, any file size).
inline Result inspect_file(const fs::path& src) {
    using namespace detail;
    try {
        std::error_code ec; u64 fileSize = (u64)fs::file_size(src, ec); if (ec) return fail(Status::IoError, ec.message());
        File f; if (!f.open(src, "rb")) return fail(Status::IoError, "cannot open the file");
        Header h; if (!read_header(f.f, h)) return fail(Status::BadFormat, "not a valid .3p file");
        Result r; r.inSize = fileSize; r.outSize = h.total; r.storedName = h.name; return r;
    } catch (const std::exception& e) { return fail(Status::IoError, e.what()); }
}

}  // namespace p3
