'use strict';
const fs=require('fs'),path=require('path'),{spawnSync}=require('child_process');
const NAME='portable-fixture.bin';
function run(cli,args){const r=spawnSync(cli,args,{encoding:'utf8',maxBuffer:4*1024*1024});if(r.error)throw r.error;if(r.status!==0)throw Error(r.stdout+r.stderr);}
function fixture(){const b=Buffer.alloc(2*1024*1024);for(let i=0;i<b.length;i++)b[i]=(i*31+(i>>>8)*7)&255;return b;}
function walk(d){return fs.readdirSync(d,{withFileTypes:true}).flatMap(e=>{const p=path.join(d,e.name);return e.isDirectory()?walk(p):[p];});}
function produce(cli,out){fs.mkdirSync(out,{recursive:true});const sd=path.join(out,'source');fs.mkdirSync(sd,{recursive:true});const src=path.join(sd,NAME);fs.writeFileSync(src,fixture());run(cli,['c',src,'-q','-v']);fs.copyFileSync(path.join(sd,path.basename(NAME,path.extname(NAME))+'.3p'),path.join(out,path.basename(NAME,path.extname(NAME))+'.3p'));fs.rmSync(sd,{recursive:true,force:true});}
function verify(cli,art,out){const files=walk(art).filter(p=>p.endsWith('.3p'));if(files.length!==3)throw Error('Expected 3 archives; found '+files.length);for(const f of files){const d=path.join(out,path.basename(path.dirname(f)));fs.mkdirSync(d,{recursive:true});run(cli,['x',f,d,'-q']);if(!fs.readFileSync(path.join(d,NAME)).equals(fixture()))throw Error('Byte mismatch: '+f);console.log('OK '+f);}}
const [mode,cli,src,dst]=process.argv.slice(2);if(mode==='produce')produce(cli,src);else if(mode==='verify')verify(cli,src,dst);else throw Error('Usage: interop-smoke.js produce|verify ...');
