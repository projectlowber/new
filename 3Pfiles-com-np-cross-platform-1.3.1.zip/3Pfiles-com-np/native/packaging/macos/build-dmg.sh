#!/usr/bin/env sh
set -eu
NATIVE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
ROOT_DIR=$(CDPATH= cd -- "$NATIVE_DIR/.." && pwd)
STAGE="$NATIVE_DIR/build/macos-stage"
APP="$STAGE/3Pfile Compressor"
OUT="$ROOT_DIR/files/3Pfile-Installer-Universal.dmg"
rm -rf "$STAGE"
mkdir -p "$APP"
install -m 0755 "$NATIVE_DIR/bin/darwin/p3cli" "$APP/3pcli"
install -m 0644 "$NATIVE_DIR/src/app.ico" "$APP/3P-App.ico"
install -m 0644 "$NATIVE_DIR/src/3p.ico" "$APP/3P-File.ico"
cat > "$APP/Install.command" <<'EOF'
#!/usr/bin/env sh
set -eu
DEST="$HOME/.local/bin"
mkdir -p "$DEST"
cp "$(dirname "$0")/3pcli" "$DEST/3pcli"
chmod 0755 "$DEST/3pcli"
printf 'Installed 3pcli to %s/3pcli\nAdd %s to PATH if needed.\n' "$DEST" "$DEST"
EOF
chmod 0755 "$APP/Install.command"
cat > "$APP/README.txt" <<'EOF'
3Pfile Compressor for macOS (universal Apple Silicon + Intel)

Double-click Install.command to install the command-line program to ~/.local/bin.
Compress and replace only when the verified archive is smaller:
  3pcli c /path/to/file --replace
Restore:
  3pcli x /path/to/file.3p
The archive stores the original filename and extension.
EOF
mkdir -p "$ROOT_DIR/files"
hdiutil create -volname "3Pfile Compressor" -srcfolder "$STAGE" -ov -format UDZO "$OUT"
