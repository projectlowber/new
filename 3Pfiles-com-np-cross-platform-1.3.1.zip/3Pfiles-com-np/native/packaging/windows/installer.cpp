#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <shobjidl.h>
#include <string>
#include <cstring>
#include "embedded_payload.hpp"

namespace {
bool writeFile(const std::wstring& path, const unsigned char* data, size_t size) {
    HANDLE file = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) return false;
    size_t offset = 0;
    while (offset < size) {
        DWORD chunk = static_cast<DWORD>((size - offset) > 0x7fffffff ? 0x7fffffff : size - offset);
        DWORD written = 0;
        if (!WriteFile(file, data + offset, chunk, &written, nullptr) || written == 0) { CloseHandle(file); return false; }
        offset += written;
    }
    FlushFileBuffers(file);
    CloseHandle(file);
    return true;
}

bool writeText(const std::wstring& path, const char* text) {
    HANDLE file = CreateFileW(path.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) return false;
    DWORD bytes = static_cast<DWORD>(strlen(text)), written = 0;
    bool ok = WriteFile(file, text, bytes, &written, nullptr) && written == bytes;
    CloseHandle(file); return ok;
}

bool makeShortcut(const std::wstring& link, const std::wstring& target, const std::wstring& icon) {
    HRESULT init = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    bool didInit = SUCCEEDED(init);
    IShellLinkW* shellLink = nullptr;
    HRESULT hr = CoCreateInstance(CLSID_ShellLink, nullptr, CLSCTX_INPROC_SERVER, IID_IShellLinkW, (void**)&shellLink);
    if (FAILED(hr)) { if (didInit) CoUninitialize(); return false; }
    shellLink->SetPath(target.c_str());
    shellLink->SetIconLocation(icon.c_str(), 0);
    IPersistFile* persist = nullptr;
    hr = shellLink->QueryInterface(IID_IPersistFile, (void**)&persist);
    if (SUCCEEDED(hr)) { hr = persist->Save(link.c_str(), TRUE); persist->Release(); }
    shellLink->Release();
    if (didInit) CoUninitialize();
    return SUCCEEDED(hr);
}

void setFileAssociation(const std::wstring& app, const std::wstring& icon) {
    HKEY ext = nullptr; bool canClaim = true;
    if (RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Classes\\.3p", 0, KEY_QUERY_VALUE, &ext) == ERROR_SUCCESS) {
        wchar_t existing[256] = {}; DWORD bytes = sizeof(existing), type = 0;
        if (RegQueryValueExW(ext, nullptr, nullptr, &type, (BYTE*)existing, &bytes) == ERROR_SUCCESS && existing[0] && wcscmp(existing, L"3PfileArchive") != 0) canClaim = false;
        RegCloseKey(ext);
    }
    if (!canClaim) return;
    HKEY key = nullptr; DWORD disposition = 0;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\Classes\\.3p", 0, nullptr, 0, KEY_SET_VALUE, nullptr, &key, &disposition) == ERROR_SUCCESS) {
        const wchar_t* value = L"3PfileArchive"; RegSetValueExW(key, nullptr, 0, REG_SZ, (const BYTE*)value, (DWORD)((wcslen(value)+1)*sizeof(wchar_t))); RegCloseKey(key);
    }
    if (RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\Classes\\3PfileArchive\\DefaultIcon", 0, nullptr, 0, KEY_SET_VALUE, nullptr, &key, &disposition) == ERROR_SUCCESS) {
        std::wstring value = icon + L",0"; RegSetValueExW(key, nullptr, 0, REG_SZ, (const BYTE*)value.c_str(), (DWORD)((value.size()+1)*sizeof(wchar_t))); RegCloseKey(key);
    }
    if (RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\Classes\\3PfileArchive\\shell\\open\\command", 0, nullptr, 0, KEY_SET_VALUE, nullptr, &key, &disposition) == ERROR_SUCCESS) {
        std::wstring value = L"\"" + app + L"\" \"%1\""; RegSetValueExW(key, nullptr, 0, REG_SZ, (const BYTE*)value.c_str(), (DWORD)((value.size()+1)*sizeof(wchar_t))); RegCloseKey(key);
    }
    SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST, nullptr, nullptr);
}
}

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    wchar_t local[MAX_PATH] = {};
    if (FAILED(SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, SHGFP_TYPE_CURRENT, local))) {
        MessageBoxW(nullptr, L"Could not find the current user's Local AppData folder.", L"3Pfile Compressor Setup", MB_OK | MB_ICONERROR); return 1;
    }
    std::wstring programsRoot = std::wstring(local) + L"\\Programs";
    if (!CreateDirectoryW(programsRoot.c_str(), nullptr) && GetLastError() != ERROR_ALREADY_EXISTS) { MessageBoxW(nullptr, L"Could not create the per-user Programs folder.", L"3Pfile Compressor Setup", MB_OK | MB_ICONERROR); return 1; }
    std::wstring folder = programsRoot + L"\\3Pfile Compressor";
    if (!CreateDirectoryW(folder.c_str(), nullptr) && GetLastError() != ERROR_ALREADY_EXISTS) {
        MessageBoxW(nullptr, L"Could not create the per-user install folder.", L"3Pfile Compressor Setup", MB_OK | MB_ICONERROR); return 1;
    }
    std::wstring app = folder + L"\\3P-Compressor.exe", cli = folder + L"\\p3cli.exe", appIcon = folder + L"\\app.ico", fileIcon = folder + L"\\3p.ico";
    const bool ok = writeFile(app, payload::gui, sizeof(payload::gui)) && writeFile(cli, payload::cli, sizeof(payload::cli)) && writeFile(appIcon, payload::appIcon, sizeof(payload::appIcon)) && writeFile(fileIcon, payload::fileIcon, sizeof(payload::fileIcon));
    const char uninstaller[] = R"UNINST(@echo off
setlocal
set "PROGRAMS=%APPDATA%\Microsoft\Windows\Start Menu\Programs"
del /q "%PROGRAMS%\3Pfile Compressor\3Pfile Compressor.lnk" "%PROGRAMS%\3Pfile Compressor\Uninstall 3Pfile Compressor.lnk" 2>nul
reg query "HKCU\Software\Classes\.3p" /ve 2>nul | findstr /i "3PfileArchive" >nul && reg delete "HKCU\Software\Classes\.3p" /ve /f >nul
reg delete "HKCU\Software\Classes\3PfileArchive" /f >nul 2>nul
cd /d "%TEMP%"
rmdir /s /q "%~dp0"
)UNINST";
    const bool textOk = writeText(folder + L"\\uninstall.cmd", uninstaller);
    if (!ok || !textOk) { MessageBoxW(nullptr, L"Installation failed while writing application files.", L"3Pfile Compressor Setup", MB_OK | MB_ICONERROR); return 1; }
    setFileAssociation(app, fileIcon);
    wchar_t programs[MAX_PATH] = {};
    if (SUCCEEDED(SHGetFolderPathW(nullptr, CSIDL_PROGRAMS, nullptr, SHGFP_TYPE_CURRENT, programs))) {
        std::wstring menu = std::wstring(programs) + L"\\3Pfile Compressor";
        CreateDirectoryW(menu.c_str(), nullptr);
        makeShortcut(menu + L"\\3Pfile Compressor.lnk", app, appIcon);
        makeShortcut(menu + L"\\Uninstall 3Pfile Compressor.lnk", folder + L"\\uninstall.cmd", appIcon);
    }
    HINSTANCE launch = ShellExecuteW(nullptr, L"open", app.c_str(), nullptr, folder.c_str(), SW_SHOWNORMAL);
    if ((INT_PTR)launch <= 32) { MessageBoxW(nullptr, L"Installed 3Pfile Compressor. Launch it from the Start menu.", L"3Pfile Compressor Setup", MB_OK | MB_ICONINFORMATION); }
    return 0;
}
