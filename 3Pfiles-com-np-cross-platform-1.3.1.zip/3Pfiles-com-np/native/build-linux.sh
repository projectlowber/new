#!/usr/bin/env sh
set -eu
NATIVE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
OUT="$NATIVE_DIR/bin/linux"
mkdir -p "$OUT"
c++ -std=c++17 -O3 -DNDEBUG -pthread "$NATIVE_DIR/src/p3cli.cpp" -o "$OUT/p3cli"
