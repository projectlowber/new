(() => {
  let installPrompt = null;
  const button = document.getElementById('installAppBtn');
  const status = document.getElementById('mobileInstallStatus');
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  }
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault(); installPrompt = event;
    if (button) button.textContent = 'Install 3Pfiles';
    if (status) status.textContent = 'Install 3Pfiles on your phone for quick access from your home screen.';
  });
  window.addEventListener('appinstalled', () => {
    installPrompt = null;
    if (status) status.textContent = '3Pfiles was added to your device.';
  });
  if (button) button.addEventListener('click', async () => {
    if (!installPrompt) {
      if (status && !/iPhone|iPad|iPod/i.test(navigator.userAgent)) status.textContent = 'Use your browser menu and choose “Install app” or “Add to Home Screen.”';
      return;
    }
    installPrompt.prompt();
    const result = await installPrompt.userChoice;
    if (status) status.textContent = result.outcome === 'accepted' ? 'Installing 3Pfiles…' : 'Installation was cancelled. You can install later from your browser menu.';
    installPrompt = null;
  });
})();
