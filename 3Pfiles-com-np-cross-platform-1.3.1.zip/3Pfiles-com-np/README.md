# 3Pfile Compression (3Pfiles.com.np)

## Deployment

For a complete single-instance Ubuntu EC2 setup, follow [AWS_EC2_DEPLOYMENT.md](AWS_EC2_DEPLOYMENT.md).

The website uses the same portable C++17 compression engine as the native clients. native/src/engine3p.hpp is the reusable engine, and native/src/p3cli.cpp is the common command-line front end. The Win32 GUI links to that same engine.

## Run the website

- Install Node.js 18 or later and a C++17 compiler on Linux/macOS.
- Run npm start from this folder. Before starting the server, it builds the native CLI for Linux/macOS automatically when that executable is missing. Windows uses the bundled native/bin/win32/p3cli.exe. The server looks for native/bin/win32/p3cli.exe, native/bin/linux/p3cli, or native/bin/darwin/p3cli. The website is served at http://localhost:3000. If that port is busy, use npm start -- --port 3001 (or set PORT=3001).
- Signing in is required before POST /API/v1/compress. It accepts raw file bytes and a URL-encoded X-File-Name header, up to 1 GB. Uploads use a temporary directory and are removed after the response. The API returns HTTP 422 when the archive is not smaller than the original. POST /API/v1/extract accepts .3p files up to 1 GB and returns the original filename from archive metadata; the web client downloads the result automatically.

## Accounts, notifications and email sharing

- Sign up with a username, email and password, or sign in. Passwords are salted and hashed with Node.js scrypt. Account and share metadata is stored under user/.private, which the static server blocks from download.
- The initial admin account is username admin, password thisisadmin. Set DEFAULT_ADMIN_PASSWORD before the first server start to seed a different password. Existing account data is not overwritten.
- After sign-in, a notification bell appears at the top right. Signup and share-link creation add notifications.
- After compression, choose Email download link. The server stores the .3p file behind a random link that expires after seven days. The browser opens a prefilled email draft for the user to send. No SMTP provider is configured, so the server does not send mail in the background.
- The original file remains on the user’s device. Download the .3p archive or email its share link.
- The upload area is a rectangular click/drop target. Selecting a regular file starts compression; selecting a .3p archive starts restoration and automatic download, with no separate operation button.


## Social login configuration

The login and signup dialogs include Google, Facebook, Apple and Discord. A provider is enabled only when its server-side credentials are present. Register these callback URLs with each provider, replacing the host with PUBLIC_BASE_URL:

- /oauth/google/callback
- /oauth/facebook/callback
- /oauth/apple/callback
- /oauth/discord/callback

Copy [.env.example](.env.example) to .env, set PUBLIC_BASE_URL and each provider credential, then start the server. The server reads .env privately and blocks .env files from static downloads. Do not commit real secrets. Google and Discord need client ID/secret; Facebook needs its app ID/secret and optional FACEBOOK_GRAPH_VERSION; Apple needs a Services ID, Team ID, Key ID and Sign in with Apple .p8 private key. OAuth state is checked on the callback; Apple identity tokens are signature and claim validated. The providers remain disabled until configured.

Compression and share exports are limited to 1,000,000,000 bytes per file. Sign-in is enforced by the browser flow and by POST /API/v1/compress.

## Native builds

- Windows x64: install MSYS2 UCRT64 MinGW-w64 GCC and Node.js, then run native/build-windows.cmd.
- Linux x86_64: run native/build-linux.sh, then native/packaging/linux/build-deb.sh on Debian/Ubuntu. The package installs the shared CLI as /usr/bin/3pcli.
- macOS Universal: run native/build-macos.sh and native/packaging/macos/build-dmg.sh on macOS with Xcode Command Line Tools. The DMG carries the CLI and an installer script.
- .github/workflows/native-installers.yml builds all three platform packages on native runners and uploads them as workflow artifacts.

The Windows download is the self-contained setup installer (3Pfile-Setup-Win64.exe); browsers download it as a file and the user runs it to install. The Windows setup installs per-user under Local AppData and creates Start Menu shortcuts. The application uses app.ico; .3p files use a separate 3p.ico icon. Existing 3Pfile associations update to the new file icon, while another application’s association is preserved. The Linux and macOS packages contain the CLI; the Win32 client includes the desktop GUI.

The website's file downloads are relative links under files/. The Windows installer is built in this workspace. Linux and macOS binary packages require the native Linux/macOS runners in the workflow; the Windows host cannot create a valid macOS DMG.

## Icon assets

Application branding and the Windows application use the first 3P Compressor artwork (`app.ico` / `app.png`). Windows `.3p` archives use the separate triple-P artwork (`3p.ico`). The installer updates an existing 3Pfile file association to the new file icon while preserving associations owned by other applications.

## Mobile web app

On supported mobile browsers, open the site over HTTPS and choose **Get app → Install 3Pfiles** to add the installable web app to the home screen. On iPhone or iPad, use Share → Add to Home Screen. The mobile layout hides desktop installer downloads. File compression and account actions require an internet connection.

Large browser uploads show progress and allow up to one hour for Node to receive the request. The app and reverse proxy must both allow the selected upload size; the configured maximum is 1,000,000,000 bytes.
