#!/usr/bin/env sh
set -eu
NATIVE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/../.." && pwd)
ROOT_DIR=$(CDPATH= cd -- "$NATIVE_DIR/.." && pwd)
VERSION=${VERSION:-2.5.0}
ARCH=${DEB_ARCH:-amd64}
PKG="$NATIVE_DIR/build/deb-root"
OUT="$ROOT_DIR/files/3Pfile-Linux-x86_64.deb"
rm -rf "$PKG"
mkdir -p "$PKG/DEBIAN" "$PKG/usr/bin" "$PKG/usr/share/doc/3pfile"
install -m 0755 "$NATIVE_DIR/bin/linux/p3cli" "$PKG/usr/bin/3pcli"
install -m 0644 "$NATIVE_DIR/src/app.ico" "$PKG/usr/share/doc/3pfile/app.ico"
cat > "$PKG/DEBIAN/control" <<EOF
Package: 3pfile-compressor
Version: $VERSION
Section: utils
Priority: optional
Architecture: $ARCH
Maintainer: 3Pfile Compression
Description: Lossless 3P file compressor
 Portable C++17 command-line compressor. Use p3cli c FILE --replace to replace a file
 only when the verified .3p archive is smaller; use p3cli x FILE.3p to restore it.
EOF
mkdir -p "$ROOT_DIR/files"
dpkg-deb --root-owner-group --build "$PKG" "$OUT"
