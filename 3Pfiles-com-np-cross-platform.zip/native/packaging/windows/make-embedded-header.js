'use strict';
const fs = require('fs');
const path = require('path');
const here = __dirname;
const files = [
  ['gui', path.join(here, '../../bin/win32/3P-Compressor.exe')],
  ['cli', path.join(here, '../../bin/win32/p3cli.exe')],
  ['icon', path.join(here, '../../src/app.ico')]
];
let output = '#pragma once\n#include <cstddef>\nnamespace payload {\n';
for (const [name, file] of files) {
  const data = fs.readFileSync(file);
  output += 'static const unsigned char ' + name + '[] = {\n';
  for (let offset = 0; offset < data.length; offset += 24) {
    output += '  ' + Array.from(data.subarray(offset, offset + 24), (v) => '0x' + v.toString(16).padStart(2, '0')).join(',') + ',\n';
  }
  output += '};\n';
}
output += '}\n';
fs.writeFileSync(path.join(here, 'embedded_payload.hpp'), output);
