@echo off
setlocal
set "NATIVE=%~dp0"
set "SRC=%NATIVE%src"
set "OUT=%NATIVE%bin\win32"
set "ROOT=%NATIVE%.."
if not exist "%OUT%" mkdir "%OUT%"
if not exist "%ROOT%\files" mkdir "%ROOT%\files"
where g++ >nul 2>nul || (echo Install MSYS2 UCRT64 MinGW-w64 and add its bin folder to PATH.& exit /b 1)
where node >nul 2>nul || (echo Node.js is required to build the embedded Windows installer.& exit /b 1)
pushd "%SRC%"
g++ -std=c++17 -O3 -s -DNDEBUG -D_WIN32_WINNT=0x0601 -DWINVER=0x0601 -DUNICODE -D_UNICODE -mwindows -municode -static -static-libgcc -static-libstdc++ -o "%OUT%\3P-Compressor.exe" gui_win32.cpp app.res -lgdiplus -lcomdlg32 -lshell32 -lole32 -luuid -lgdi32 -luser32 -ladvapi32
if errorlevel 1 (popd& exit /b 1)
g++ -std=c++17 -O3 -s -DNDEBUG -D_WIN32_WINNT=0x0601 -DWINVER=0x0601 -static -static-libgcc -static-libstdc++ -o "%OUT%\p3cli.exe" p3cli.cpp
if errorlevel 1 (popd& exit /b 1)
copy /y app.ico "%OUT%\app.ico" >nul
popd
node "%NATIVE%packaging\windows\make-embedded-header.js"
g++ -std=c++17 -O2 -s -DNDEBUG -mwindows -municode -static -static-libgcc -static-libstdc++ -o "%ROOT%\files\3Pfile-Setup-Win64.exe" "%NATIVE%packaging\windows\installer.cpp" "%SRC%\app.res" -lshell32 -lole32 -luuid -ladvapi32 -luser32
if errorlevel 1 exit /b 1
exit /b 0
