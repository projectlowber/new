# Deploy 3Pfiles on AWS EC2 (Ubuntu)

This guide deploys the current Node.js website/API and shared C++ compression engine on one Ubuntu EC2 instance, with Nginx and HTTPS. It is a single-instance setup; it does not configure a shared database, object storage, or server-side email delivery.

## Project requirements and important limits

- Node.js 18 or newer. These instructions install Node.js 24 LTS; check the [Node.js release schedule](https://nodejs.org/en/about/previous-releases).
- A C++17 compiler to build the Linux compressor. The project bundle does not contain a Linux executable; build it on the Ubuntu instance.
- Persistent writable storage for account JSON, share metadata, and retained files. By default this is user/.private; set P3_DATA_DIR to place it on a separate EBS data volume. Preserve it during updates and exclude it from public downloads.
- Disk capacity for temporary uploads under /tmp and retained account files. The app accepts files up to 1,000,000,000 bytes and does not automatically purge soft-deleted files.
- The application stores accounts in local JSON and sessions in memory. Keep one EC2 instance for this version. Restarting the service requires users to sign in again.
- Email share opens a prefilled email draft on the user's device; EC2 does not send the email.

## 1. Launch EC2

1. In the AWS Console, open EC2 and choose Launch instance. See [AWS launch instructions](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/LaunchingAndUsingInstances.html).
2. Select a current Ubuntu Server LTS AMI, for example Ubuntu 24.04 LTS. Use an architecture supported by the AMI. x86_64 is the simplest initial target.
3. Choose instance memory and EBS size for expected compression load and file retention. Compression is CPU and memory intensive; the 1 GB upload limit does not mean a small instance can handle every 1 GB file.
4. Create/download an SSH key pair and keep the private key secure.
5. Create a security group with inbound rules: SSH TCP 22 from your current IP only, HTTP TCP 80 from the internet, and HTTPS TCP 443 from the internet. Do not expose Node port 3000 publicly. See [EC2 security groups](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/creating-security-group.html).
6. Place the instance in a public subnet with internet access. Allocate and associate an Elastic IP so the website IP remains stable. AWS charges for public IPv4 addresses, including Elastic IPs; see [Elastic IP details and pricing](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/elastic-ip-addresses-eip.html).
7. Use EBS snapshots or another backup plan for account data.

For SSH, Ubuntu instances use username ubuntu. See [Connect to a Linux EC2 instance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/connect-to-linux-instance.html).

## 2. Configure DNS

At your DNS provider, create an A record for your website hostname pointing to the Elastic IP. For Route 53, see [DNS routing to an EC2 web server](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/dns-configuring-new-domain.html). Wait until DNS resolves to the Elastic IP before requesting a certificate. Use the same hostname in PUBLIC_BASE_URL below.

## 3. Connect and install packages

From Windows PowerShell, replace the key path and IP:

~~~powershell
ssh -i "$env:USERPROFILE\Downloads\ec2-key.pem" ubuntu@EC2_PUBLIC_IP
~~~

On the EC2 host:

~~~bash
sudo apt update
sudo apt upgrade -y
sudo apt install -y build-essential nginx unzip curl ca-certificates snapd
~~~

Install the latest Node.js 24.x official Linux archive and verify its checksum:

~~~bash
cd /tmp
case "$(dpkg --print-architecture)" in
  amd64) NODE_ARCH=x64 ;;
  arm64) NODE_ARCH=arm64 ;;
  *) echo "Unsupported Ubuntu architecture"; exit 1 ;;
esac
NODE_FILE="$(curl -fsSL https://nodejs.org/dist/latest-v24.x/SHASUMS256.txt | awk -v arch="$NODE_ARCH" '$2 ~ "^node-v24\\..*-linux-" arch "\\.tar\\.xz$" {print $2; exit}')"
test -n "$NODE_FILE"
curl -fsSLO "https://nodejs.org/dist/latest-v24.x/$NODE_FILE"
curl -fsSL https://nodejs.org/dist/latest-v24.x/SHASUMS256.txt | grep " $NODE_FILE$" | sha256sum -c -
sudo tar -xJf "$NODE_FILE" -C /usr/local --strip-components=1
node --version
npm --version
~~~

Node.js publishes official downloads and checksums at [nodejs.org](https://nodejs.org/en/download).


## 3A. Resize the root volume and prepare a separate data volume

The assessment shows an 8 GiB root volume. Increase it in EC2 **Volumes → select the root volume → Actions → Modify volume** and set the target size (40 GiB is a reasonable starting point for a small deployment). Take an EBS snapshot first. Wait for the modification to enter optimizing or completed before growing the guest partition and filesystem. AWS documents this process in [Extend the file system after resizing an EBS volume](https://docs.aws.amazon.com/ebs/latest/userguide/recognize-expanded-volume-linux.html).

Run the following commands in an SSH session on the Ubuntu EC2 instance, not in the local PowerShell terminal or CloudShell. Do not assume device names from the EC2 console mapping. Inspect the guest's actual root device and filesystem:

~~~bash
sudo apt install -y cloud-guest-utils
lsblk -f
findmnt -no SOURCE,FSTYPE /
df -hT /
~~~

For a common Nitro Ubuntu layout where root is /dev/nvme0n1p1, grow partition 1 from its parent disk, then grow the filesystem according to the FSTYPE shown above:

~~~bash
sudo growpart /dev/nvme0n1 1
# For ext4 only:
sudo resize2fs /dev/nvme0n1p1
# For XFS only, use this instead of resize2fs:
sudo xfs_growfs -d /
df -hT /
~~~

Use only the filesystem command matching the reported filesystem. For a Xen-style /dev/xvda1 root, the growpart device/partition pair is /dev/xvda 1, and an ext4 filesystem would be grown on /dev/xvda1. AWS notes that Nitro EBS devices are presented as NVMe names and may not match the attachment name; inspect lsblk before running any grow or format command. See [EBS NVMe device names](https://docs.aws.amazon.com/ebs/latest/userguide/identify-nvme-ebs-device.html).

For a separate data volume:

1. In the EC2 console, create a gp3 EBS volume in the exact same Availability Zone as the instance. Use ap-southeast-2b only if the instance details confirm it is in ap-southeast-2b. A 10 GiB volume is only a small smoke-test starting point; saved files and soft-deleted files consume space, so size it for your expected retention.
2. Attach the volume to the instance. In the guest, identify it using lsblk and its size/serial, for example:

~~~bash
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINTS,SERIAL
~~~

3. Do not format a device that already has a filesystem or data. Only after confirming the new volume is blank, set DATA_DEVICE below to the actual whole-device path shown by lsblk (often /dev/nvme1n1 on Nitro), then format it:

~~~bash
DATA_DEVICE=/dev/nvme1n1   # Replace with the confirmed new, blank device
sudo mkfs.ext4 "$DATA_DEVICE"
sudo mkdir -p /var/lib/3pfiles
sudo mount "$DATA_DEVICE" /var/lib/3pfiles
sudo blkid "$DATA_DEVICE"
~~~

4. Copy the UUID printed by blkid into /etc/fstab so the volume mounts reliably after reboot. Use the filesystem UUID, not the transient NVMe device name:

~~~text
UUID=REPLACE_WITH_FILESYSTEM_UUID /var/lib/3pfiles ext4 defaults,nofail 0 2
~~~

Then verify the fstab entry and mount:

~~~bash
sudo mount -a
findmnt /var/lib/3pfiles
df -hT /var/lib/3pfiles
~~~

5. After the 3pfiles service user has been created, assign ownership with sudo chown 3pfiles:3pfiles /var/lib/3pfiles. Add this line to the app's .env before the first service start:

~~~dotenv
P3_DATA_DIR=/var/lib/3pfiles
~~~

The app now honors P3_DATA_DIR for accounts, shares, and retained files. If a server has already stored account data under the app's user/.private directory, stop the service and copy that directory's contents to the mounted volume before setting P3_DATA_DIR; do not mount over the old directory because that hides its contents.

For a new volume attached after instance launch, verify its EC2 **Delete on termination** setting is **No** so it is preserved if the instance is terminated. EBS data-volume defaults differ by attachment method; AWS recommends checking the setting. See [Preserve EBS volumes on instance termination](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/preserving-volumes-on-termination.html). A snapshot is still needed for backup and point-in-time recovery.

## 4. Upload and install the project

In a second PowerShell window on your computer, upload the project ZIP:

~~~powershell
scp -i "$env:USERPROFILE\Downloads\ec2-key.pem" "C:\path\to\3Pfiles-com-np-cross-platform.zip" ubuntu@EC2_PUBLIC_IP:/tmp/
~~~

Back in the EC2 session, create the restricted service user and unpack the project:

~~~bash
sudo useradd --system --create-home --home-dir /opt/3pfiles --shell /usr/sbin/nologin 3pfiles
sudo mkdir -p /opt/3pfiles/app
sudo unzip -q /tmp/3Pfiles-com-np-cross-platform.zip -d /opt/3pfiles/app
sudo chown -R 3pfiles:3pfiles /opt/3pfiles
~~~

Build the Linux C++ CLI:

~~~bash
sudo -u 3pfiles sh -c 'cd /opt/3pfiles/app && ./native/build-linux.sh'
ls -l /opt/3pfiles/app/native/bin/linux/p3cli
~~~

If the script is not executable, run chmod +x native/build-linux.sh from the project directory, then build again.

## 5. Set production environment

Create the private environment file:

~~~bash
sudo nano /opt/3pfiles/app/.env
~~~

Set these values. Use your real hostname and a long, unique password:

~~~dotenv
PORT=3000
PUBLIC_BASE_URL=https://YOUR_DOMAIN
P3_DATA_DIR=/var/lib/3pfiles
DEFAULT_ADMIN_PASSWORD=PUT_A_LONG_UNIQUE_PASSWORD_HERE
~~~

Lock down the file:

~~~bash
sudo chown 3pfiles:3pfiles /opt/3pfiles/app/.env
sudo chmod 600 /opt/3pfiles/app/.env
~~~

Set DEFAULT_ADMIN_PASSWORD before the first start. It seeds the initial admin account only if no account data exists. Editing it later does not reset an existing admin password. Use a separate named account for regular work.

OAuth is optional. Provider secrets and required fields are listed in .env.example. Register callbacks with the exact public hostname:

~~~text
https://YOUR_DOMAIN/oauth/google/callback
https://YOUR_DOMAIN/oauth/facebook/callback
https://YOUR_DOMAIN/oauth/apple/callback
https://YOUR_DOMAIN/oauth/discord/callback
~~~

The social providers stay disabled until their credentials are configured. Never put OAuth secrets in browser files or commit .env.

## 6. Run under systemd

Create /etc/systemd/system/3pfiles.service:

~~~ini
[Unit]
Description=3Pfiles website and compression API
After=network.target

[Service]
Type=simple
User=3pfiles
Group=3pfiles
WorkingDirectory=/opt/3pfiles/app
Environment=NODE_ENV=production
EnvironmentFile=/opt/3pfiles/app/.env
ExecStart=/usr/local/bin/node /opt/3pfiles/app/server.js
Restart=on-failure
RestartSec=5
UMask=0077
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
~~~

If command -v node reports a different path, use that path in ExecStart. Then start the app:

~~~bash
sudo systemctl daemon-reload
sudo systemctl enable --now 3pfiles
sudo systemctl status 3pfiles --no-pager
curl -I http://127.0.0.1:3000/
sudo journalctl -u 3pfiles -n 100 --no-pager
~~~

Do not continue until the local curl returns an HTTP response.

## 7. Configure Nginx and large uploads

Create /etc/nginx/sites-available/3pfiles and replace YOUR_DOMAIN:

~~~nginx
server {
    listen 80;
    listen [::]:80;
    server_name YOUR_DOMAIN www.YOUR_DOMAIN;
    client_max_body_size 1g;
    client_body_timeout 3600s;
    send_timeout 3600s;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_request_buffering off;
        proxy_buffering off;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }
}
~~~

Enable and check the Nginx site:

~~~bash
sudo ln -s /etc/nginx/sites-available/3pfiles /etc/nginx/sites-enabled/3pfiles
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t
sudo systemctl reload nginx
~~~

Nginx allows up to 1 GiB through to the app; the app enforces its precise 1,000,000,000-byte limit.

## 8. Enable HTTPS

After DNS resolves and inbound TCP 80/443 are open, follow [Certbot's Nginx instructions](https://certbot.eff.org/instructions?os=snap&tab=standard&ws=nginx):

~~~bash
sudo snap install --classic certbot
sudo ln -s /snap/bin/certbot /usr/local/bin/certbot
sudo certbot --nginx -d YOUR_DOMAIN -d www.YOUR_DOMAIN
sudo systemctl list-timers | grep certbot
~~~

Follow the prompt to redirect HTTP to HTTPS.

## 9. Verify the website

1. Visit https://YOUR_DOMAIN and create an account.
2. Compress a small file; confirm the .3p appears in My Files and downloads.
3. Select a .3p file in the upload area; confirm it restores and the browser downloads the original automatically.
4. Create a folder, select one or more files, choose Move, choose a destination, and confirm. Cancel should leave files where they were.
5. Check the account notification bell and review service logs if something fails.
6. Test installer links. This project tree currently contains the Windows installer only. Build and put the Linux and macOS packages under files/ using the exact filenames referenced by index.html before those download links can work.

The email-share flow creates a link and opens an email draft in the user's own mail application. It does not send mail from the EC2 server.

## 10. Backups, updates, and storage

When P3_DATA_DIR=/var/lib/3pfiles is set, persistent private data is under /var/lib/3pfiles, including accounts.json, shares/, and account-files/. Without P3_DATA_DIR, it defaults to /opt/3pfiles/app/user/.private. Do not expose or replace this directory during an update. Back it up to encrypted, access-controlled storage and test restoration.

Example local backup:

~~~bash
sudo systemctl stop 3pfiles
sudo tar -C /var/lib -czf /var/backups/3pfiles-private-data.tar.gz 3pfiles
sudo systemctl start 3pfiles
sudo chmod 600 /var/backups/3pfiles-private-data.tar.gz
~~~

For app updates, back up the directory named by P3_DATA_DIR, stop the service, deploy code while preserving that data directory and .env, rebuild native/bin/linux/p3cli if the C++ source changed, then start the service and review logs. Avoid deployment commands that delete unknown files from the app folder.

Soft-deleted files remain stored. Set a disk capacity and retention policy before inviting public signups. Larger deployments should replace local JSON/session state and local file storage with a shared database and durable object storage.

## Official references

- [Launch an EC2 instance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/LaunchingAndUsingInstances.html)
- [Create an EC2 security group](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/creating-security-group.html)
- [Connect to Linux EC2](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/connect-to-linux-instance.html)
- [Elastic IP addresses](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/elastic-ip-addresses-eip.html)
- [Route 53 DNS routing](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/dns-configuring-new-domain.html)
- [Node.js release schedule](https://nodejs.org/en/about/previous-releases)
- [Certbot and Nginx](https://certbot.eff.org/instructions?os=snap&tab=standard&ws=nginx)
