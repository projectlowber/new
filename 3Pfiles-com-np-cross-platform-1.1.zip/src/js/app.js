document.addEventListener('DOMContentLoaded', () => {
  const dropOrb = document.getElementById('dropOrb');
  const fileInput = document.getElementById('fileInput');
  const orbTitle = document.getElementById('orbTitle');
  const orbMeta = document.getElementById('orbMeta');
  const compressionStatus = document.getElementById('compressionStatus');
  const downloadToast = document.getElementById('downloadToast');
  const copyApiBtn = document.getElementById('copyApiBtn');
  const apiCodeBlock = document.getElementById('apiCodeBlock');
  const loginModal = document.getElementById('loginModal');
  const openLoginBtn = document.getElementById('openLoginBtn');
  const closeLoginBtn = document.getElementById('closeLoginBtn');
  const loginForm = document.getElementById('loginForm');
  const signupForm = document.getElementById('signupForm');
  const authLoginPane = document.getElementById('authLoginPane');
  const authSignupPane = document.getElementById('authSignupPane');
  const authAccountPane = document.getElementById('authAccountPane');
  const authStatus = document.getElementById('authStatus');
  const notificationBell = document.getElementById('notificationBell');
  const notificationCount = document.getElementById('notificationCount');
  const notificationPanel = document.getElementById('notificationPanel');
  const notificationList = document.getElementById('notificationList');
  const shareModal = document.getElementById('shareModal');
  const shareForm = document.getElementById('shareForm');
  const shareEmail = document.getElementById('shareEmail');
  const shareStatus = document.getElementById('shareStatus');
  const activateProBtn = document.getElementById('activateProBtn');
  let pendingShare = null;
  let currentUser = null;
  let pendingFileOperation = null;
  let busy = false;

  function showAuth(mode) {
    loginModal.hidden = false;
    notificationPanel.hidden = true;
    if (currentUser) {
      authLoginPane.hidden = true; authSignupPane.hidden = true; authAccountPane.hidden = false;
      document.getElementById('loginTitle').textContent = 'Your account';
      document.getElementById('signedInName').textContent = 'Signed in as ' + currentUser.username + ' (' + currentUser.email + ')';
      authStatus.textContent = 'Your account is ready to share compressed files.';
      return;
    }
    const signup = mode === 'signup'; authLoginPane.hidden = signup; authSignupPane.hidden = !signup; authAccountPane.hidden = true;
    document.getElementById('loginTitle').textContent = signup ? 'Create your account' : 'Sign in to 3Pfiles';
    authStatus.textContent = signup ? 'Create an account to share compressed archives.' : 'Sign in or create an account to share compressed archives.';
  }
  function setCurrentUser(user) {
    currentUser = user || null;
    notificationBell.hidden = !currentUser;
    document.getElementById('openLoginBtn').textContent = currentUser ? currentUser.username : 'Sign in';
    const accountLink = document.getElementById('accountPageLink'); if (accountLink) accountLink.hidden = !currentUser;
    if (currentUser) refreshNotifications();
  }
  async function refreshNotifications() {
    if (!currentUser) return;
    try {
      const response = await fetch('/API/v1/notifications', { credentials: 'same-origin' });
      if (!response.ok) return;
      const data = await response.json(), notes = data.notifications || [], unread = notes.filter(n => !n.read).length;
      notificationCount.textContent = unread > 9 ? '9+' : String(unread);
      notificationCount.hidden = unread === 0;
      notificationList.replaceChildren();
      if (!notes.length) { const li = document.createElement('li'); li.textContent = 'You are all caught up.'; notificationList.appendChild(li); }
      for (const note of notes) {
        const li = document.createElement('li'), time = document.createElement('time');
        li.className = note.read ? '' : 'unread'; li.appendChild(document.createTextNode(note.text));
        time.dateTime = note.createdAt; time.textContent = new Date(note.createdAt).toLocaleString(); li.appendChild(time); notificationList.appendChild(li);
      }
    } catch (_) { /* Keep the account UI available while notifications refresh. */ }
  }
  function openShareDialog() {
    if (!pendingShare) return;
    loginModal.hidden = true; shareStatus.textContent = ''; shareEmail.value = ''; shareModal.hidden = false; shareEmail.focus();
  }
  async function submitAuth(endpoint, payload) {
    const response = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify(payload) });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Could not sign in.');
    setCurrentUser(data.user); loginModal.hidden = true;
    if (pendingShare) openShareDialog();
    else if (pendingFileOperation) { const task = pendingFileOperation; pendingFileOperation = null; compressSelectedFile(task.file); }
  }
  function formatBytes(bytes) {
    if (bytes < 1024) return bytes + ' B';
    const units = ['KB', 'MB', 'GB', 'TB'];
    let value = bytes / 1024;
    let i = 0;
    while (value >= 1024 && i < units.length - 1) { value /= 1024; i++; }
    return value.toFixed(value >= 100 ? 0 : 2) + ' ' + units[i];
  }

  async function trackDownload(name, libraryId) {
    if (!currentUser) return;
    try {
      await fetch('/API/v1/notifications/download', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify({ fileName: name, libraryId: libraryId || '' }) });
      await refreshNotifications();
    } catch (_) { /* A notification failure must not interrupt a download. */ }
  }

  function downloadArchive(blob, name, libraryId) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    trackDownload(name, libraryId);
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  function addAction(label, action) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn-pill btn-primary';
    button.textContent = label;
    button.addEventListener('click', action);
    compressionStatus.appendChild(document.createTextNode(' '));
    compressionStatus.appendChild(button);
  }

  function selectFile(file) {
    if (!file || busy) return;
    pendingShare = null; compressionStatus.textContent = '';
    if (file.size > 1000000000) {
      orbTitle.textContent = 'File exceeds the 1 GB limit'; orbMeta.textContent = file.name;
      compressionStatus.textContent = 'Files larger than 1 GB cannot be compressed, restored, or shared.'; return;
    }
    const operation = /\.3p$/i.test(file.name) ? 'uncompress' : 'compress';
    orbTitle.textContent = (operation === 'compress' ? 'Starting compression: ' : 'Starting restore: ') + file.name;
    orbMeta.textContent = formatBytes(file.size);
    if (operation === 'compress' && !currentUser) {
      pendingFileOperation = { file, operation }; showAuth('login');
      authStatus.textContent = 'Sign in to start compressing this file. It will continue after sign-in.'; return;
    }
    if (operation === 'compress') compressSelectedFile(file); else uncompressSelectedFile(file);
  }
  async function chooseFile() {
    if (busy) return;
    if (window.showOpenFilePicker) {
      try { const [handle] = await window.showOpenFilePicker({ multiple: false }); selectFile(await handle.getFile()); }
      catch (error) { if (error.name !== 'AbortError') compressionStatus.textContent = error.message || 'Could not open that file.'; }
    } else fileInput.click();
  }
  function setPanelBusy(value) { dropOrb.setAttribute('aria-busy', String(value)); dropOrb.classList.toggle('processing', value); }
  async function compressSelectedFile(file) {
    if (!currentUser) { pendingFileOperation = { file, operation: 'compress' }; showAuth('login'); authStatus.textContent = 'Sign in before compressing files.'; return; }
    busy = true; pendingShare = null; setPanelBusy(true);
    orbTitle.textContent = 'Compressing ' + file.name + '…'; orbMeta.textContent = 'Lossless .3p compression'; compressionStatus.textContent = 'Uploading to the native C++ compressor…';
    try {
      const response = await fetch('/API/v1/compress', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-File-Name': encodeURIComponent(file.name) }, body: file });
      if (!response.ok) { const detail = await response.json().catch(() => ({})); if (response.status === 401) { pendingFileOperation = { file, operation: 'compress' }; showAuth('login'); } throw new Error(detail.error || 'Compression failed.'); }
      const blob = await response.blob(), originalBytes = Number(response.headers.get('X-Original-Bytes') || file.size), compressedBytes = Number(response.headers.get('X-Compressed-Bytes') || blob.size), libraryId = response.headers.get('X-Library-Id');
      const savings = Math.max(0, Math.round((1 - compressedBytes / originalBytes) * 100));
      const archiveName = decodeURIComponent(response.headers.get('X-Output-Name') || encodeURIComponent(file.name + '.3p'));
      orbTitle.textContent = 'Compression complete'; orbMeta.textContent = formatBytes(originalBytes) + ' → ' + formatBytes(compressedBytes);
      compressionStatus.textContent = 'Reduced by ' + savings + '%. The archive is verified by the native compressor.';
      pendingShare = { blob, archiveName };
      addAction('Email download link', () => { if (currentUser) openShareDialog(); else { showAuth('login'); authStatus.textContent = 'Sign in to share this archive.'; } });
      addAction('Download .3p', () => downloadArchive(blob, archiveName, libraryId));
    } catch (error) { orbTitle.textContent = 'Compression stopped'; orbMeta.textContent = file.name; compressionStatus.textContent = error.message || 'Compression failed.'; }
    finally { busy = false; setPanelBusy(false); }
  }
  async function uncompressSelectedFile(file) {
    busy = true; setPanelBusy(true);
    orbTitle.textContent = 'Uncompressing ' + file.name + '…'; orbMeta.textContent = 'Restoring the original file'; compressionStatus.textContent = 'The restored file will download automatically.';
    try {
      const response = await fetch('/API/v1/extract', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-File-Name': encodeURIComponent(file.name) }, body: file });
      if (!response.ok) { const detail = await response.json().catch(() => ({})); throw new Error(detail.error || 'Could not uncompress this archive.'); }
      const blob = await response.blob(), encodedName = response.headers.get('X-Output-Name'), name = encodedName ? decodeURIComponent(encodedName) : file.name.replace(/\.3p$/i, ''), libraryId = response.headers.get('X-Library-Id');
      downloadArchive(blob, name, libraryId); compressionStatus.textContent = 'Restored file downloaded automatically.';
      orbTitle.textContent = 'Uncompression complete'; orbMeta.textContent = name + ' · ' + formatBytes(blob.size);
    } catch (error) { orbTitle.textContent = 'Uncompression stopped'; orbMeta.textContent = file.name; compressionStatus.textContent = error.message || 'Could not uncompress this archive.'; }
    finally { busy = false; setPanelBusy(false); }
  }
  dropOrb.addEventListener('click', event => { if (event.target.closest('a,button')) return; chooseFile(); });
  dropOrb.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); chooseFile(); } });
  fileInput.addEventListener('change', event => { selectFile(event.target.files[0]); fileInput.value = ''; });
  dropOrb.addEventListener('dragover', event => { event.preventDefault(); dropOrb.classList.add('drag-over'); });
  dropOrb.addEventListener('dragleave', () => dropOrb.classList.remove('drag-over'));
  dropOrb.addEventListener('drop', event => { event.preventDefault(); dropOrb.classList.remove('drag-over'); selectFile(event.dataTransfer.files[0]); });

  document.querySelectorAll('.os-circle-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const os = btn.dataset.os;
      const filePath = btn.dataset.file;
      const fileName = filePath.split('/').pop();
      const link = document.createElement('a');
      link.href = new URL(filePath, document.baseURI).href;
      link.download = fileName;
      link.rel = 'noopener';
      downloadToast.textContent = os === 'windows' ? 'Downloading the Windows setup installer (.exe). Run the downloaded file to install 3Pfiles.' : 'Starting download for ' + os.toUpperCase() + '…';
      document.body.appendChild(link);
      link.click();
      link.remove();
    });
  });

  copyApiBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(apiCodeBlock.textContent).then(() => {
      copyApiBtn.textContent = 'Copied!';
      setTimeout(() => (copyApiBtn.textContent = 'Copy cURL'), 1800);
    });
  });

  openLoginBtn.addEventListener('click', () => showAuth('login'));
  document.getElementById('showSignupBtn').addEventListener('click', () => showAuth('signup'));
  document.getElementById('showLoginBtn').addEventListener('click', () => showAuth('login'));
  if (activateProBtn) activateProBtn.addEventListener('click', () => showAuth('login'));
  closeLoginBtn.addEventListener('click', () => (loginModal.hidden = true));
  loginModal.addEventListener('click', (event) => { if (event.target === loginModal) loginModal.hidden = true; });
  document.getElementById('closeShareBtn').addEventListener('click', () => (shareModal.hidden = true));
  shareModal.addEventListener('click', (event) => { if (event.target === shareModal) shareModal.hidden = true; });
  loginForm.addEventListener('submit', async (event) => {
    event.preventDefault(); authStatus.textContent = 'Signing in…';
    try { await submitAuth('/API/v1/auth/login', { username: document.getElementById('loginUsername').value, password: document.getElementById('loginPassword').value }); }
    catch (error) { authStatus.textContent = error.message; }
  });
  signupForm.addEventListener('submit', async (event) => {
    event.preventDefault(); authStatus.textContent = 'Creating account…';
    try { await submitAuth('/API/v1/auth/signup', { username: document.getElementById('signupUsername').value, email: document.getElementById('signupEmail').value, password: document.getElementById('signupPassword').value }); }
    catch (error) { authStatus.textContent = error.message; }
  });
  document.getElementById('logoutBtn').addEventListener('click', async () => {
    await fetch('/API/v1/auth/logout', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    currentUser = null; notificationBell.hidden = true; notificationPanel.hidden = true; loginModal.hidden = true;
    document.getElementById('openLoginBtn').textContent = 'Sign in';
  });
  notificationBell.addEventListener('click', async () => {
    const opening = notificationPanel.hidden; notificationPanel.hidden = !opening;
    notificationBell.setAttribute('aria-expanded', String(opening));
    if (opening) await refreshNotifications();
  });
  document.getElementById('markNotificationsRead').addEventListener('click', async () => {
    await fetch('/API/v1/notifications/read', { method: 'POST', credentials: 'same-origin' }).catch(() => {});
    await refreshNotifications();
  });
  shareForm.addEventListener('submit', async (event) => {
    event.preventDefault(); if (!pendingShare || !currentUser) return;
    const submit = shareForm.querySelector('button[type="submit"]'); submit.disabled = true; shareStatus.textContent = 'Creating a seven-day share link…';
    try {
      const response = await fetch('/API/v1/shares', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream', 'X-Recipient-Email': shareEmail.value, 'X-File-Name': encodeURIComponent(pendingShare.archiveName) }, body: pendingShare.blob });
      const data = await response.json().catch(() => ({})); if (!response.ok) throw new Error(data.error || 'Could not create share link.');
      const link = new URL('/s/' + data.token, window.location.origin).href;
      const subject = 'A compressed file shared with you';
      const message = 'Download ' + data.fileName + ' using this link (expires in 7 days):\n\n' + link + '\n\nShared from 3Pfiles.';
      const mailto = 'mailto:' + encodeURIComponent(shareEmail.value.trim()) + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(message);
      shareStatus.textContent = 'Share link created. Your email app will open a draft; press Send to email it. Link: ' + link;
      await refreshNotifications();
      window.location.href = mailto;
      pendingShare = null;
    } catch (error) { shareStatus.textContent = error.message || 'Could not share this archive.'; }
    finally { submit.disabled = false; }
  });
  document.querySelectorAll('.oauth-button').forEach(button => {
    button.addEventListener('click', () => { if (!button.disabled) window.location.assign('/oauth/' + button.dataset.provider); });
  });
  fetch('/API/v1/auth/providers', { credentials: 'same-origin' }).then(async response => {
    if (!response.ok) return;
    const data = await response.json(); let active = 0;
    document.querySelectorAll('.oauth-button').forEach(button => {
      const enabled = !!(data.providers && data.providers[button.dataset.provider]);
      button.disabled = !enabled; button.title = enabled ? 'Continue with ' + button.textContent : 'Configure this OAuth provider on the server to enable sign-in.';
      if (enabled) active++;
    });
    document.getElementById('oauthSetupNote').textContent = active ? 'Enabled social sign-in providers are ready.' : 'Social sign-in activates after provider credentials are configured on the server.';
  }).catch(() => {});
  const authQuery = new URLSearchParams(window.location.search);
  if (authQuery.get('accountLogin') === '1') { showAuth('login'); history.replaceState(null, '', window.location.pathname + window.location.hash); }
  if (authQuery.has('authError')) { showAuth('login'); authStatus.textContent = authQuery.get('authError') === 'provider_not_configured' ? 'That social sign-in provider is not configured yet.' : authQuery.get('authError'); history.replaceState(null, '', window.location.pathname + window.location.hash); }
  if (authQuery.get('auth') === 'success') { compressionStatus.textContent = 'Signed in successfully.'; history.replaceState(null, '', window.location.pathname + window.location.hash); }
  fetch('/API/v1/auth/me', { credentials: 'same-origin' }).then(async response => {
    if (!response.ok) return;
    setCurrentUser((await response.json()).user);
    if (pendingFileOperation) { const task = pendingFileOperation; pendingFileOperation = null; loginModal.hidden = true; compressSelectedFile(task.file); }
  }).catch(() => {});

});
