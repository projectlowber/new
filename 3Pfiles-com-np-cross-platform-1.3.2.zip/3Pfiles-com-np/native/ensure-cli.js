'use strict';

const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const root = path.resolve(__dirname, '..');
const platform = process.platform === 'win32' ? 'win32' : process.platform === 'darwin' ? 'darwin' : process.platform === 'linux' ? 'linux' : null;
if (!platform) { console.error('3Pfiles compression is not supported on this server platform: ' + process.platform); process.exit(1); }
const cli = process.env.P3CLI_PATH ? path.resolve(process.env.P3CLI_PATH) : path.join(root, 'native', 'bin', platform, platform === 'win32' ? 'p3cli.exe' : 'p3cli');
function hasMemoryBudgetSupport() {
  if (!fs.existsSync(cli)) return false;
  const probe = spawnSync(cli, ['--supports-memory-budget'], { cwd: root, stdio: 'ignore', windowsHide: true });
  return probe.status === 0;
}
if (hasMemoryBudgetSupport()) process.exit(0);
if (process.env.P3CLI_PATH) { console.error('P3CLI_PATH must point to a compressor built from the current source (including -m memory budget support): ' + cli); process.exit(1); }
let result;
if (platform === 'win32') {
  const compiler = process.env.CXX || 'g++';
  result = spawnSync(compiler, ['-std=c++17', '-O3', '-s', '-DNDEBUG', '-D_WIN32_WINNT=0x0601', '-DWINVER=0x0601', '-static', '-static-libgcc', '-static-libstdc++', '-o', cli, path.join(__dirname, 'src', 'p3cli.cpp')], { cwd: root, stdio: 'inherit', windowsHide: true });
} else {
  const buildScript = platform === 'darwin' ? 'build-macos.sh' : 'build-linux.sh';
  result = spawnSync('/bin/sh', [path.join(__dirname, buildScript)], { cwd: root, stdio: 'inherit' });
}
if (result.error) { console.error('Could not start the native compressor build:', result.error.message); process.exit(1); }
if (result.status !== 0 || !hasMemoryBudgetSupport()) { console.error('Could not build a compatible native compressor. Install a C++17 compiler and retry npm start.'); process.exit(result.status || 1); }
console.log('Built a memory-limited ' + platform + ' 3P compressor at ' + cli);
